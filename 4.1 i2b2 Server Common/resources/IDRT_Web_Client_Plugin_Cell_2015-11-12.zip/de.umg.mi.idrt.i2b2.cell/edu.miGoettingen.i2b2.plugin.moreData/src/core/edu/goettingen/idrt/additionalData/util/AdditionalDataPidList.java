package edu.goettingen.idrt.additionalData.util;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AdditionalDataPidList {
	private List<AdditionalDataPid> pidList;
	
	@XmlElement(name = "pid")
	public List<AdditionalDataPid> getPidList() {
		if (pidList == null) {
			pidList = new ArrayList<AdditionalDataPid>();
		}
		return pidList;
	}
}
