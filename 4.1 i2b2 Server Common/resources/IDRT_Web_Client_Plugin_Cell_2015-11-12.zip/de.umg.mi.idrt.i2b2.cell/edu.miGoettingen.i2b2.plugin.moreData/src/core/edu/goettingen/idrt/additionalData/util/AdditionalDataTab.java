package edu.goettingen.idrt.additionalData.util;

import java.util.List;
import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AdditionalDataTab {
	private String tabName;
	private String id;
	private List<AdditionalDataColumn> columns;
	
	public String getTabName() { return tabName; }
	
	public String getId() { return id; }
	
	@XmlAttribute(name="name")
	public void setTabName(String name) { tabName = name; }
	
	@XmlAttribute(name="id")
	public void setId(String uid) { id = uid; }
	
	@XmlElement(name = "column")
	public List<AdditionalDataColumn> getColumns() {
		if (columns == null) {
			columns = new ArrayList<AdditionalDataColumn>();
		}
		return columns;
	}
}
