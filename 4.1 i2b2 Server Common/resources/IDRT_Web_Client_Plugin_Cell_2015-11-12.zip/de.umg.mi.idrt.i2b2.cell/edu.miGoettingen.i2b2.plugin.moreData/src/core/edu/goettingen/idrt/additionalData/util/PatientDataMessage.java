/*
 * Copyright (c) 2006-2010 Massachusetts General Hospital 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the i2b2 Software License v2.1 
 * which accompanies this distribution. 
 * 
 * Contributors:
 *     Mike Mendis - initial API and implementation
 */

package edu.goettingen.idrt.additionalData.util;

import edu.harvard.i2b2.common.exception.I2B2Exception;
import edu.harvard.i2b2.common.util.jaxb.JAXBUnWrapHelper;
import edu.harvard.i2b2.common.util.jaxb.JAXBUtil;
import edu.harvard.i2b2.common.util.jaxb.JAXBUtilException;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.BodyType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.RequestMessageType;
import edu.goettingen.idrt.additionalData.datavo.pdo.ObservationSet;
import edu.goettingen.idrt.additionalData.datavo.pdo.PatientDataType;
import edu.goettingen.idrt.additionalData.datavo.pdo.ObservationType;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.List;

import javax.xml.bind.JAXBElement;


/**
 * The PatientDataMessage class is a helper class to build the messages in the
 * i2b2 format
 */
public class PatientDataMessage {
	private static Log log = LogFactory.getLog(PatientDataMessage.class);
	private JAXBUtil jaxbUtil = null;
	RequestMessageType reqMessageType = null;

	/**
	 * The constructor
	 */
	public PatientDataMessage(String requestPdo) throws I2B2Exception {
		jaxbUtil = new JAXBUtil(JAXBConstant.DEFAULT_PACKAGE_NAME);

		try {
			JAXBElement jaxbElement = jaxbUtil.unMashallFromString(requestPdo);

			if (jaxbElement == null) {
				throw new I2B2Exception(
						"Null value from unmarshall for PDO xml : " + requestPdo);
			}

			this.reqMessageType = (RequestMessageType) jaxbElement.getValue();
		} catch (JAXBUtilException e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
			throw new I2B2Exception("Umashaller error: " + e.getMessage() +
					requestPdo, e);
		}
	}

	/**
	 * Function to get PatientData object from i2b2 request message type
	 * @return
	 * @throws JAXBUtilException
	 */
	public PatientDataType getPatientDataType() throws JAXBUtilException {
		BodyType bodyType = reqMessageType.getMessageBody();
		JAXBUnWrapHelper helper = new JAXBUnWrapHelper();
		PatientDataType patientDataType = (PatientDataType) helper.getObjectByClass(bodyType.getAny(),
				PatientDataType.class);

		return patientDataType;
	}

	/**
	 * Function to read the PFT report from the PFT client request in
	 * preparation for processing
	 *
	 * @param requestPdo
	 *            String Request PDO containing PFT report in observationBlob
	 * @return ObservationFactType
	 *                         ObservationBlob contains report in String format
	 * @throws Exception
	 */
	public ObservationType getObservationFact() throws I2B2Exception {
		ObservationType obsFactType = null;

		try {
			BodyType bodyType = reqMessageType.getMessageBody();

			JAXBUnWrapHelper helper = new JAXBUnWrapHelper();
			PatientDataType patientDataType = (PatientDataType) helper.getObjectByClass(bodyType.getAny(),
					PatientDataType.class);
			List<ObservationSet> obsFactSet = patientDataType.getObservationSet();

			if ((obsFactSet != null) && (obsFactSet.size() > 0)) {
				if (obsFactSet.get(0).getObservation().size() == 0) {
					log.error("No Observation fact was found in requestPdo");
					throw new I2B2Exception(
					"No Observation fact was found in requestPdo");
				} else {
					obsFactType = obsFactSet.get(0).getObservation().get(0);
				}
			} else {
				log.error("No Observation fact set was found in requestPdo");
				throw new I2B2Exception(
				"No Observation fact set was found in requestPdo");
			}
		} catch (JAXBUtilException e) {
			e.printStackTrace();
			log.error("Error extracting Obs Fact Set List from request PDO", e);
			throw new I2B2Exception("Error extracting Obs Fact Set List from request PDO",
					e);
		}

		return obsFactType;
	}

	public RequestMessageType getRequestMessageType() { 
		return reqMessageType;
	}
}
