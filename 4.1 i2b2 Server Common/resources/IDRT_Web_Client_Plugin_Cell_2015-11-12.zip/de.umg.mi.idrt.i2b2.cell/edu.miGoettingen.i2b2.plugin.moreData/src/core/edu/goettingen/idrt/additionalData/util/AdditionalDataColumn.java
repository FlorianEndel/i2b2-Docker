package edu.goettingen.idrt.additionalData.util;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class AdditionalDataColumn {
	private String header;
	private String valueType;
	private List<AdditionalDataObservation> observations;
	
	public String getHeader() { return header; }
	
	public String getValueType() { return valueType; }
	
	@XmlAttribute(name="header")
	public void setHeader(String name) { header = name; }
	
	@XmlAttribute(name="valueType")
	public void setValueType(String val) { valueType = val; }
	
	@XmlElement(name = "observation")
	public List<AdditionalDataObservation> getObservations() {
		if (observations == null) {
			observations = new ArrayList<AdditionalDataObservation>();
		}
		return observations;
	}
}
