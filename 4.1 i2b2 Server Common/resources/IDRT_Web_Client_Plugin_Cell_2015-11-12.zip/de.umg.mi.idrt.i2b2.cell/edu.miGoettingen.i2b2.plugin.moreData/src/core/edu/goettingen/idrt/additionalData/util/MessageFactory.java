package edu.goettingen.idrt.additionalData.util;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.impl.llom.util.AXIOMUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Node;

import edu.goettingen.idrt.additionalData.util.NamespacePrefixMapperImpl;
import edu.harvard.i2b2.common.exception.I2B2Exception;
import edu.goettingen.idrt.additionalData.datavo.crcmessage.MasterRequestType;
import edu.goettingen.idrt.additionalData.datavo.crcmessage.MasterResponseType;
import edu.goettingen.idrt.additionalData.datavo.crcmessage.PsmQryHeaderType;
import edu.goettingen.idrt.additionalData.datavo.crcmessage.PsmRequestTypeType;
import edu.goettingen.idrt.additionalData.datavo.crcmessage.QueryMasterType;
import edu.goettingen.idrt.additionalData.datavo.crcmessage.UserType;
import edu.goettingen.idrt.additionalData.datavo.crcontmessage.ConceptType;
import edu.goettingen.idrt.additionalData.datavo.crcontmessage.ConceptsType;
import edu.goettingen.idrt.additionalData.datavo.crcontmessage.GetTermInfoType;
import edu.goettingen.idrt.additionalData.datavo.crcontmessage.ModifierType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.ConstrainDateTimeType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.ConstrainDateType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.InclusiveType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.ItemType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.MetadataxmlValueType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.PanelType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.PatientDataResponseType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.ApplicationType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.BodyType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.FacilityType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.RequestHeaderType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.RequestMessageType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.MessageHeaderType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.ResponseHeaderType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.ResponseMessageType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.ResultStatusType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.SecurityType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.StatusType;
import edu.goettingen.idrt.additionalData.datavo.pdo.BlobType;
import edu.goettingen.idrt.additionalData.datavo.pdo.ObservationSet;
import edu.goettingen.idrt.additionalData.datavo.pdo.PatientDataType;
import edu.goettingen.idrt.additionalData.datavo.pdo.PidSet;

public class MessageFactory {
	private static Log log = LogFactory.getLog(MessageFactory.class);
	private static JAXBContext context = initContext();
	
	private static JAXBContext initContext() {
		log.debug("Init JAXB Context");
		Class<?>[] classes = new Class[36];
		classes[0] = RequestMessageType.class;
		classes[1] = RequestHeaderType.class;
		classes[2] = BodyType.class;
		classes[3] = MessageHeaderType.class;
		classes[4] = ResponseMessageType.class;
		classes[5] = MasterResponseType.class;  
		classes[6] = QueryMasterType.class;
		classes[7] = QueryDefinition.class;
		classes[8] = PanelType.class;
		classes[9] = ConstrainDateType.class;
		classes[10] = ItemType.class;
		classes[11] = MetadataxmlValueType.class;
		classes[12] = XMLGregorianCalendar.class;
		classes[13] = ConstrainDateTimeType.class;
		classes[14] = InclusiveType.class;
		classes[15] = ConceptsType.class;  
		classes[16] = ConceptType.class;
		classes[17] = ModifierType.class;
		classes[18] = BlobType.class;
		classes[19] = GetTermInfoType.class;
		classes[20] = PsmQryHeaderType.class;
		classes[21] = MasterRequestType.class;
		classes[22] = UserType.class;
		classes[23] = PsmRequestTypeType.class;
		classes[24] = ApplicationType.class;
		classes[25] = FacilityType.class;
		classes[26] = SecurityType.class;
		classes[27] = PatientDataResponseType.class;
		classes[28] = PatientDataType.class;
		classes[29] = PidSet.class;
		classes[30] = ObservationSet.class;
		classes[31] = AdditionalDataTab.class;
		classes[32] = AdditionalDataColumn.class;
		classes[33] = AdditionalDataObservation.class;
		classes[34] = ResponseHeaderType.class;
		classes[35] = AdditionalDataPidList.class;
		
		try {
			return JAXBContext.newInstance(classes);
		} catch (JAXBException e) {
			log.error("Critical Error Loading JAXB Context");
			e.printStackTrace();
			throw new RuntimeException("Critical Error Loading JAXB Context");
		}
	}

	public static MessageHeaderType createMessageHeader(SecurityType security, String projectId) {
		log.debug("Creating Message Header Type");
		MessageHeaderType msgHeader = new MessageHeaderType();
    	ApplicationType sendingApp = new ApplicationType();
    	ApplicationType receivingApp = new ApplicationType();
    	FacilityType facility = new FacilityType();
    	
    	sendingApp.setApplicationName("i2b2_IdrtAdditionalDataCell");
    	receivingApp.setApplicationName("i2b2_DataRepositoryCell");
    	sendingApp.setApplicationVersion("1.6");
    	receivingApp.setApplicationVersion("1.6");
    	facility.setFacilityName("PHS");
    	
    	msgHeader.setSendingApplication(sendingApp);
    	msgHeader.setSendingFacility(facility);
    	msgHeader.setReceivingApplication(receivingApp);
    	msgHeader.setReceivingFacility(facility);
    	msgHeader.setSecurity(security);
    	msgHeader.setProjectId(projectId);	
    	return msgHeader;
    }
	
	public static RequestMessageType createRequestMessage(BodyType body, SecurityType sec, String p) {
		RequestMessageType request = new RequestMessageType();
		request.setRequestHeader(createRequestHeader());
		request.setMessageHeader(createMessageHeader(sec, p));
		request.setMessageBody(body);
		return request;
	}
	
	
    public static RequestHeaderType createRequestHeader() {
    	log.debug("Creating Request Header Type");
    	RequestHeaderType requestHeader = new RequestHeaderType();
    	requestHeader.setResultWaittimeMs(180000);
    	return requestHeader;
    }  

	public static PsmQryHeaderType createPsmHeader(PsmRequestTypeType requestType, SecurityType security) {
    	log.debug("Creating PSM Header Type");
		UserType user = new UserType();
    	user.setLogin(security.getUsername());
    	user.setValue(security.getUsername());
    	
    	PsmQryHeaderType psmHeader = new PsmQryHeaderType();
    	psmHeader.setEstimatedTime(0);
    	psmHeader.setPatientSetLimit(0);
    	psmHeader.setUser(user);
    	psmHeader.setRequestType(requestType);
    	return psmHeader;
    }
    
	private static ResponseHeaderType createResponseHeader(String type, String value) {
        log.debug("Creating Response Header Type");
		ResponseHeaderType respHeader = new ResponseHeaderType();
        StatusType status = new StatusType();
        status.setType(type);
        status.setValue(value);

        ResultStatusType resStat = new ResultStatusType();
        resStat.setStatus(status);
        respHeader.setResultStatus(resStat);
        return respHeader;
    }

    public static OMElement createOMElement(RequestMessageType request) throws I2B2Exception {
    	edu.goettingen.idrt.additionalData.datavo.i2b2message.ObjectFactory of
    	= new edu.goettingen.idrt.additionalData.datavo.i2b2message.ObjectFactory();
    	JAXBElement<RequestMessageType> jaxbData = of.createRequest(request);
    	return marshallAndOmConvert(jaxbData);
    }
	
	public static OMElement createOMElement(ResponseMessageType response) throws I2B2Exception {
    	edu.goettingen.idrt.additionalData.datavo.i2b2message.ObjectFactory of
    	= new edu.goettingen.idrt.additionalData.datavo.i2b2message.ObjectFactory();
    	JAXBElement<ResponseMessageType> jaxbData = of.createResponse(response);
    	return marshallAndOmConvert(jaxbData);	
    }
	
	//TODO: unstatic machen try and make unstatic ... fkcing classloader
	private static OMElement marshallAndOmConvert(JAXBElement<?> jaxbData) throws I2B2Exception {
		log.debug("Formatting the Message Using JAXB");
		
		try {
			StringWriter writer = new StringWriter();
			Marshaller marshaller = context.createMarshaller();
			marshaller.setProperty("com.sun.xml.bind.xmlDeclaration", Boolean.TRUE);
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);      
			marshaller.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapperImpl());
			marshaller.marshal(jaxbData, writer);
			
			log.debug("Converting the Message using AXIOM: " + writer.toString());

			//XMLStreamReader reader =  XMLInputFactory.newInstance().createXMLStreamReader(new StringReader(writer.toString()));
			//StAXOMBuilder builder = new StAXOMBuilder(reader);
			//OMElement element = builder.getDocumentElement();
			
			OMElement element = AXIOMUtil.stringToOM(writer.toString());
			return element;
		} catch (Exception ex) {
			log.error("Error in createOMResponse. Lines 190 - 198");
			throw new I2B2Exception(ex.toString());
		}
	}
    
    public static ResponseMessageType doBuildErrorResponse(String errorMessage) {
    	log.debug("Creating Response Message Type (Error)");
        ResponseMessageType respMessageType = null;

        MessageHeaderType messageHeader = createMessageHeader(null, null);
        ResponseHeaderType respHeader = createResponseHeader("ERROR", errorMessage);
        respMessageType = createResponseMessageType(messageHeader, respHeader, null);
        return respMessageType;
    }

    public static ResponseMessageType createResponseMessageType(
    		MessageHeaderType messageHeader,
    		ResponseHeaderType respHeader,
    		BodyType bodyType) {
    	log.debug("Creating Response Header Type (Normal)");
        ResponseMessageType respMsgType = new ResponseMessageType();
        respMsgType.setMessageHeader(messageHeader);
        respMsgType.setMessageBody(bodyType);
        respMsgType.setResponseHeader(respHeader);
        return respMsgType;
    }

    public static <T> JAXBElement<T> unmarshal(Node domNode, Class<T> declaredType) throws JAXBException {
    	log.debug("Unmarshalling Received Object");
    	Unmarshaller unmarshaller = context.createUnmarshaller();
    	JAXBElement<T> jaxbElement = unmarshaller.unmarshal(domNode, declaredType);
    	return jaxbElement;
    }
    
    @SuppressWarnings("unchecked")
	public static <T> JAXBElement<T> unmarshal(String xmlMessage, Class<T> declaredType) throws JAXBException {
		log.debug("Unmarshalling Received Object");
		Unmarshaller unmarshaller = context.createUnmarshaller();
		JAXBElement<T> jaxbElement = (JAXBElement<T>) unmarshaller.unmarshal(new StringReader(xmlMessage));
		return jaxbElement;
	}

	@SuppressWarnings("unchecked")
	public static <T> T unmarshalDirect(String xmlMessage, Class<T> declaredType) throws JAXBException {
		log.debug("Unmarshalling Received Object");
		Unmarshaller unmarshaller = context.createUnmarshaller();
		T element = (T) unmarshaller.unmarshal(new StringReader(xmlMessage));
		return element;
	}
}