package edu.goettingen.idrt.additionalData.util;

import javax.xml.bind.annotation.XmlAttribute;

public class AdditionalDataPid {
	private String pid;
	private String mappedPid;

	public String getMappedPid() { return mappedPid; }
	
	public String getPid() { return pid; }
	
	@XmlAttribute(name="mapped")
	public void setMappedPid(String in) { mappedPid = in; }
	
	@XmlAttribute(name="hive")
	public void setPid(String in) { pid = in; }
}