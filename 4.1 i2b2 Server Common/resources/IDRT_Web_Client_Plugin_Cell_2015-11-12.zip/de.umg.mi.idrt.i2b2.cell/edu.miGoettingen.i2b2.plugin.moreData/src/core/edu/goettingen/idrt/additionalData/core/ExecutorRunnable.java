package edu.goettingen.idrt.additionalData.core;

import edu.harvard.i2b2.common.exception.I2B2Exception;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.SecurityType;
import edu.goettingen.idrt.additionalData.datavo.pdo.PatientDataType;

import org.apache.axiom.om.OMElement;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * Implements thread runnable interface, to do the
 * processing using thread.
 */
public class ExecutorRunnable implements Runnable {
    private static Log log = LogFactory.getLog(ExecutorRunnable.class);
    private OMElement output = null;
    private OMElement input;
    private I2B2Exception ex = null;
    private boolean jobCompleteFlag = false;
    private String queryMasterId = null;
    private String queryResultId = null;
    private String projectId = null;
    private String url = null;
    private SecurityType security;
	private long waitTime;
	private boolean isRefine;
    
    public I2B2Exception getJobException() {
        return ex;
    }

    public boolean isJobCompleteFlag() {
        return jobCompleteFlag;
    }

    public void setJobCompleteFlag(boolean jobCompleteFlag) {
        this.jobCompleteFlag = jobCompleteFlag;
    }

    public void setServiceUrl(String url) {
    	this.url = url;
    }
    
    public void setJobException(I2B2Exception ex) {
        this.ex = ex;
    }
    
    public void setSecurity(SecurityType sec) {
    	security = sec;
    }

    public String getQueryMasterId() {
        return queryMasterId;
    }
    
    public void setProjectId(String proId) {
    	projectId = proId;
    }

    public void setQueryMasterId(String masterId) {
        queryMasterId = masterId;
    }
    
    public void setResultId(String resultId) {
    	queryResultId = resultId;
    }

    public OMElement getOutput() {
        return output;
    }

	public void setWaitTime(long waitTime) {
		this.waitTime = waitTime;
	}
	
	public long getWaitTime() {
		return waitTime;
	}
	
	public void setRefinement(boolean refine) {
		this.isRefine = refine;
	}
	
	public void setInput(OMElement in) {
		input = in;
	}
    
    public void run() {
        log.debug("MOREDATA: Running from thread ...");

        try {
        	AdditionalDataHelper helper = new AdditionalDataHelper(security, projectId, url);
        	
	        if (isRefine) {
	        	// Refinement Query
	        	PatientDataType response = helper.getResponseForQuery(input);
	        	output = helper.evaluateResponse(response);
	        	setJobCompleteFlag(true);
	        } else {
	        	// Normal Query
	        	//Get the PatientData from the CRC Cell
	        	log.debug("MOREDATA: Getting Response using QueryMasterId");
	        	PatientDataType response = helper.getResponseForQueryMasterId(queryMasterId, queryResultId);
	        		
	        	//Refine the PatientData to a much shorter (XML) response
	        	log.debug("MOREDATA: Got Response. Evaluate now");
	        	output = helper.evaluateResponse(response);
	        	
	            setJobCompleteFlag(true);
	            log.debug("MOREDATA: Running from thread, completed extracting concepts ...");
	        }
	    } catch (I2B2Exception e) {
	    	log.debug(e.toString());
	        setJobException(e);
	    }
    }
}
