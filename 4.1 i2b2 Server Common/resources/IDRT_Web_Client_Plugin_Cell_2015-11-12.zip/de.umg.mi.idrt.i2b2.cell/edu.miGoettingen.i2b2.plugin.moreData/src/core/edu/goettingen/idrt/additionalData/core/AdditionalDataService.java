/*
 * Copyright (c) 2006-2010 Massachusetts General Hospital 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the i2b2 Software License v2.1 
 * which accompanies this distribution. 
 * 
 * Contributors:
 *     Mike Mendis - initial API and implementation
 */

package edu.goettingen.idrt.additionalData.core;

import javax.xml.namespace.QName;

import edu.goettingen.idrt.additionalData.util.MessageFactory;
import edu.goettingen.idrt.additionalData.util.PatientDataMessage;
import edu.harvard.i2b2.common.exception.I2B2Exception;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.PasswordType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.ResponseMessageType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.SecurityType;

import org.apache.axiom.om.OMElement;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * This is webservice skeleton class. It passes incoming report to PFT parser
 * and collects parsed pft concepts. Then these parsed concepts returned back to
 * webservice client in Patient Data Object XML format.
 *
 */
public class AdditionalDataService {
	private static Log log = LogFactory.getLog(AdditionalDataService.class);

	/**
	 * This function is main webservice interface to get regex data from
	 * observation blob. It uses AXIOM elements(OMElement) to conveniently parse
	 * xml messages.
	 *
	 * It excepts incoming request in i2b2 message format, which wraps date
	 * report inside patientdata object. The response is also will be in i2b2
	 * message, which will wrap patientdata object. Patient data object will
	 * have all the extracted regex concepts from the report.
	 *
	 *
	 * @param getMoreDataElement
	 * @return OMElement in i2b2message format
	 * @throws Exception
	 */
	public OMElement getAdditionalData(OMElement received) throws I2B2Exception {
		ExecutorRunnable er = prepareData(received);

		log.debug("Create PatientDataMessage");
		PatientDataMessage input = new PatientDataMessage(received.toString());
		//String projectId = null;
		
		/*log.debug("MOREDATA: Get Project ID from Message");
		if (input.getRequestMessageType() != null) {
			if (input.getRequestMessageType().getMessageHeader() != null) {
				projectId = input.getRequestMessageType().
						getMessageHeader().
						getProjectId();
			}
		}*/
		
		log.debug("MOREDATA: Get QueryMaster ID from Message");
		// Get the QueryMasterId
		String queryMasterId = input.getObservationFact().getEventId().getValue();
		String resultId = input.getObservationFact().getPatientId().getValue();
		
		log.debug("MOREDATA: Found Query Master ID: " + queryMasterId);		
		er.setQueryMasterId(queryMasterId); // Query ID
		er.setResultId(resultId);			// Patient Set
		//er.setProjectId(projectId);
		//er.setSecurity(input.getRequestMessageType().getMessageHeader().getSecurity());
		
		return applyData(er);
	}
	
	public OMElement getRefinementData(OMElement received) throws I2B2Exception {
		ExecutorRunnable er = prepareData(received);
		er.setRefinement(true);
		return applyData(er);
	}
	
	private ExecutorRunnable prepareData(OMElement received) throws I2B2Exception {
		String queryString = String.valueOf(received);
		
		log.debug("MOREDATA: Received Request PDO Element " + queryString);
		if (received == null) {
			log.error("MOREDATA: But AdditionalData Request it is NULL");
			throw new I2B2Exception("Incoming AdditionalData Request is null");
		}

		// Get the Service URL from query
		String url = received
		.getFirstChildWithName(new QName("message_header"))
		.getFirstChildWithName(new QName("proxy"))
		.getFirstChildWithName(new QName("redirect_url"))
		.getText();
		
		// Get the waittime
		long waitTime = Long.valueOf(received
		.getFirstChildWithName(new QName("request_header"))
		.getFirstChildWithName(new QName("result_waittime_ms"))
		.getText()).longValue();
		
		// Get the server url and remove the service specific part!
		url = url.substring(0, url.indexOf("IdrtAdditionalData"));
		log.debug("ADDD: Got Service URL: " + url);

		// Get the security data
		SecurityType security = new SecurityType();
		OMElement sec = received.getFirstChildWithName(new QName("message_header")).getFirstChildWithName(new QName("security"));
		security.setDomain(sec.getFirstChildWithName(new QName("domain")).getText());
		security.setUsername(sec.getFirstChildWithName(new QName("username")).getText());
		
		PasswordType password = new PasswordType();
		password.setIsToken(true);
		password.setTokenMsTimeout(1800000);
		password.setValue(sec.getFirstChildWithName(new QName("password")).getText());
		security.setPassword(password);
		
		String projectId = received.getFirstChildWithName(new QName("message_header")).getFirstChildWithName(new QName("project_id")).getText();
		
		// Start the Runner
		ExecutorRunnable er = new ExecutorRunnable();
		er.setServiceUrl(url);
		er.setWaitTime(waitTime);
		er.setInput(received);
		er.setSecurity(security);
		er.setProjectId(projectId);
		return er;
	}
		
	private OMElement applyData(ExecutorRunnable er) throws I2B2Exception {
		Thread t = new Thread(er);
		OMElement threadResponse = null;
		
		log.debug("MOREDATA: Start Synchronized Thread");
		synchronized (t) {
			long waitTime = er.getWaitTime();
			
			log.debug("MOREDATA: Starting ThreadRunner, waiting " + waitTime + " MS!");
			t.start();

			try {
				if (waitTime > 0) {
					t.wait(waitTime);
				} else {
					t.wait();
				}

				log.debug("MOREDATA: Getting Output String of ThreadRunner");
				threadResponse = er.getOutput();

				if (threadResponse == null) {
					if (er.getJobException() != null) {
						log.debug("MOREDATA: ThreadResponse is NULL and Exception is available!");
						throw er.getJobException();
					} else if (er.isJobCompleteFlag() == false) {
						log.debug("MOREDATA: ThreadResponse is NULL and Job NOT COMPLETE. Add more waittime!");
						String timeOuterror = "MOREDATA: Result waittime millisecond <result_waittime_ms> :" +
						waitTime + " elapsed, try again with increased value";
						log.info(timeOuterror);

						ResponseMessageType responseMsgType = MessageFactory.doBuildErrorResponse(timeOuterror);
						threadResponse = MessageFactory.createOMElement(responseMsgType);
					} else {
						log.error("MOREDATA: ThreadResponse is NULL");
						throw new I2B2Exception("Error: Response is null");
					}
				}
			} catch (InterruptedException e) {
				log.debug("MOREDATA: ThreadRunner was interrupted!");
				e.printStackTrace();
				throw new I2B2Exception("MOREDATA: Thread error while running AdditionalData job", e);
			} finally {
				log.debug("MOREDATA: Stopping ThreadRunner and freeing memory");
				t.interrupt();
				er = null;
				t = null;
			}
		}
		
		log.debug("MOREDATA: Returning Response to Webclient");
		return threadResponse;
	}
}
