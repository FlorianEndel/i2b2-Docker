package edu.goettingen.idrt.additionalData.core;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.axiom.om.OMElement;
import org.apache.axis2.AxisFault;
import org.apache.axis2.Constants;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Element;

import edu.goettingen.idrt.additionalData.util.MessageFactory;
import edu.goettingen.idrt.additionalData.util.QueryDefinition;
import edu.harvard.i2b2.common.exception.I2B2Exception;
import edu.goettingen.idrt.additionalData.datavo.crcmessage.MasterRequestType;
import edu.goettingen.idrt.additionalData.datavo.crcmessage.MasterResponseType;
import edu.goettingen.idrt.additionalData.datavo.crcmessage.ObjectFactory;
import edu.goettingen.idrt.additionalData.datavo.crcmessage.PsmRequestTypeType;
import edu.goettingen.idrt.additionalData.datavo.crcmessage.QueryMasterType;
import edu.goettingen.idrt.additionalData.datavo.crcontmessage.ConceptType;
import edu.goettingen.idrt.additionalData.datavo.crcontmessage.ConceptsType;
import edu.goettingen.idrt.additionalData.datavo.crcontmessage.GetTermInfoType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.FactOutputOptionType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.FilterListType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.GetPDOFromInputListRequestType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.InputOptionListType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.OutputOptionListType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.OutputOptionSelectType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.OutputOptionType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.PatientDataResponseType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.PatientListType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.PdoQryHeaderType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.PdoRequestTypeType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.BodyType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.RequestMessageType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.ResponseMessageType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.SecurityType;
import edu.goettingen.idrt.additionalData.datavo.pdo.PatientDataType;

public class CRCMessagingUtil {
    private static Log log = LogFactory.getLog(CRCMessagingUtil.class);
    
	private ServiceClient sender;
    private String psmUrl = null;
    private String pdoUrl = null;
    private String ontUrl = null;
    private SecurityType security;
    private String projectId;
   
    public CRCMessagingUtil(SecurityType sec, String proId, String url) throws I2B2Exception {  	
    	log.debug("Creating a CRC Messaging UTIL");
    	
    	psmUrl = url + "QueryToolService/request";
    	pdoUrl = url + "QueryToolService/pdorequest";
    	ontUrl = url + "OntologyService/getTermInfo";
    	
    	log.debug("Creating the ServiceClient for Communication");
    	try {
			sender = new ServiceClient();
		} catch (AxisFault e) {
			log.error("Error while creating a new Service Client!");
			throw new I2B2Exception("Error while creating a new Service Client!");
		}
  		Options options = new Options();
  		options.setTransportInProtocol(Constants.TRANSPORT_HTTP);
  		options.setProperty(Constants.Configuration.ENABLE_REST, Constants.VALUE_TRUE);
  		options.setTimeOutInMilliSeconds(6000000);
  		sender.setOptions(options);
  		
    	// Use the given User
    	security = sec;
    	projectId = proId;
    }
       
    public String sendQMMessageToCRC(String queryId) throws I2B2Exception {
    	log.debug("Task given to create a masterID-query for the CRC cell");
    	BodyType messageBody = new BodyType();
    	List<Object> contents = messageBody.getAny();
    	ObjectFactory objFactory = new ObjectFactory();
    	
    	MasterRequestType masterRequest = new MasterRequestType();
    	masterRequest.setQueryMasterId(queryId);
    	contents.add(objFactory.createPsmheader(MessageFactory.createPsmHeader(PsmRequestTypeType.CRC_QRY_GET_REQUEST_XML_FROM_QUERY_MASTER_ID, security)));
    	contents.add(objFactory.createRequest(masterRequest));
    	
    	return sendQuery(MessageFactory.createRequestMessage(messageBody, security, projectId), 0);
    }
      
    public String sendXMLMessageToCRC(QueryDefinition querydefinition, String patientSetId) throws I2B2Exception {
    	log.debug("Task given to create a patient-query for the CRC cell");
    	BodyType messageBody = new BodyType();
    	List<Object> contents = messageBody.getAny();
    	 	
    	PdoQryHeaderType pdoHeader = new PdoQryHeaderType();
    	pdoHeader.setPatientSetLimit(200000);
    	pdoHeader.setEstimatedTime(180000);
    	pdoHeader.setRequestType(PdoRequestTypeType.GET_PDO_FROM_INPUT_LIST);
    	
    	log.debug("Creating fiterlist of the query");
    	GetPDOFromInputListRequestType pdoRequest = new GetPDOFromInputListRequestType();
    	
    	PatientListType patientList = new PatientListType();
    	patientList.setMax(4740992);
    	patientList.setMin(0);
    	
    	InputOptionListType inputList = new InputOptionListType();
    	inputList.setPatientList(patientList);
    	
    	FilterListType filterList = new FilterListType();
    	filterList.getPanel().addAll(querydefinition.getPanel());
	    
    	log.debug("Creating Output options for query");
    	FactOutputOptionType obsSet = new FactOutputOptionType();
    	obsSet.setBlob(true);
    	obsSet.setOnlykeys(false);
    	
    	OutputOptionType conceptSet = new OutputOptionType();
    	conceptSet.setOnlykeys(false);
    	conceptSet.setSelect(OutputOptionSelectType.USING_FILTER_LIST);
    	
    	OutputOptionType modifierSet = new OutputOptionType();
    	modifierSet.setOnlykeys(false);
    	modifierSet.setSelect(OutputOptionSelectType.USING_FILTER_LIST);
    	
    	OutputOptionListType outputList = new OutputOptionListType();
    	outputList.setObservationSet(obsSet);
    	outputList.setConceptSetUsingFilterList(conceptSet);
    	outputList.setModifierSetUsingFilterList(modifierSet);
    	
    	if (patientSetId.equals("")) {
    		log.debug("All Patients will be queried. No PatientSet given");
        	patientList.setPatientSetCollId(null);
        	patientList.setEntirePatientSet(true);
    	} else {
    		log.debug("PatientSet given. Specific patients will be queried");
    		patientList.setPatientSetCollId(patientSetId);
    	}
		
	    OutputOptionType pidSet = new OutputOptionType();
    	pidSet.setOnlykeys(false);
	    pidSet.setSelect(OutputOptionSelectType.USING_FILTER_LIST);
    	outputList.setPidSet(pidSet);
	
    	pdoRequest.setInputList(inputList);
    	pdoRequest.setOutputOption(outputList);
    	pdoRequest.setFilterList(filterList);
    	
    	edu.goettingen.idrt.additionalData.datavo.crcpdomessage.ObjectFactory pdoFactory =
    	new edu.goettingen.idrt.additionalData.datavo.crcpdomessage.ObjectFactory();
    	contents.add(pdoFactory.createPdoheader(pdoHeader));
    	contents.add(pdoFactory.createRequest(pdoRequest));
    	log.debug("Completed build of main query!");
    	
    	return sendQuery(MessageFactory.createRequestMessage(messageBody, security, projectId), 1);
    }
    
    @SuppressWarnings("rawtypes")
	public QueryDefinition extractRequestXML(String responseFormQMId) throws I2B2Exception {
    	log.debug("Trying to extract RequestXML from given String");

    	try {
    		ResponseMessageType responseMsg = MessageFactory.unmarshal(responseFormQMId, ResponseMessageType.class).getValue();
    		MasterResponseType mrt = (MasterResponseType)((JAXBElement)responseMsg.getMessageBody().getAny().get(0)).getValue();
    		QueryMasterType qmt = mrt.getQueryMaster().get(0);
    		
    		Element domNode = (Element) qmt.getRequestXml().getContent().get(0);
    		TransformerFactory transFactory = TransformerFactory.newInstance();
    		Transformer transformer = transFactory.newTransformer();
    		StringWriter buffer = new StringWriter();
    		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
    		transformer.transform(new DOMSource(domNode), new StreamResult(buffer));
    		String querydefinition = buffer.toString();
    		log.debug("RequestXML was transformed to String: " + querydefinition);
    		
    		querydefinition = querydefinition.replaceFirst("<(.*?)query_definition(.*?)>", "<query_definition>");
    		querydefinition = querydefinition.replaceFirst("</(.*?)query_definition(.*?)>", "</query_definition>");
    		log.debug("Querydefinition was modifed! Result: " + querydefinition);
    		
    		return MessageFactory.unmarshalDirect(querydefinition, QueryDefinition.class);
    	} catch (Exception e) {
    		log.error("Exception in Extracting XML. Lines 175 - 192");
    		throw new I2B2Exception(e.toString());
    	}
    }

    @SuppressWarnings("unchecked")
	public PatientDataType extractPatientData(String responseFromPdo) throws I2B2Exception {
    	log.debug("MOREDATA: Trying to extract raw PatientData from given String.");

    	try {
    		ResponseMessageType responseMsg = MessageFactory.unmarshal(responseFromPdo, ResponseMessageType.class).getValue();
    		PatientDataResponseType pdrt = ((JAXBElement<PatientDataResponseType>) responseMsg.getMessageBody().getAny().get(0)).getValue();
    		return pdrt.getPatientData();
    	} catch (JAXBException e) { 
    		throw new I2B2Exception(e.toString());
    	}
    }
    
 
    
    private String sendQuery(RequestMessageType request, int requestType) throws I2B2Exception {
    	log.debug("Got order to send a query to CRC cell");
    	OMElement omRequest = null;
    	OMElement omResponse = null;
    	
    	switch (requestType) {
    	case 0: sender.getOptions().setTo(new EndpointReference(psmUrl)); break;
    	case 1: sender.getOptions().setTo(new EndpointReference(pdoUrl)); break;
    	default: sender.getOptions().setTo(new EndpointReference(ontUrl)); break;
    	}
    	
    	try {
			omRequest = MessageFactory.createOMElement(request);
			omResponse = sender.sendReceive(omRequest);
		} catch (Exception e) {
			log.error("Error in CRCMessaging Line 226 - 227");
			throw new I2B2Exception(e.toString());
		}
    	if (omResponse == null) throw new I2B2Exception("Empty Answer from CRC to AdditionalData!");
    	
    	log.debug("Query was succesfully executed. Answer is: " + omResponse);
    	return omResponse.toString();
    }
    
	@SuppressWarnings("unchecked")
	public void getDaModifierName(String modifierPath, String appliedPath, HashMap<String, AdditionalDataHelper.ModContainer> modNames) throws I2B2Exception {
		log.debug("Data for Modifier is required!");
    	BodyType messageBody = new BodyType();
    	List<Object> contents = messageBody.getAny();
    	
    	GetTermInfoType termInfoRequest = new GetTermInfoType();
    	termInfoRequest.setBlob(true);
    	termInfoRequest.setType("core");
    	termInfoRequest.setSynonyms(false);
    	termInfoRequest.setHiddens(true);
    	termInfoRequest.setMax(300);
    	termInfoRequest.setSelf(modifierPath);
    	
    	edu.goettingen.idrt.additionalData.datavo.crcontmessage.ObjectFactory of =
    	new edu.goettingen.idrt.additionalData.datavo.crcontmessage.ObjectFactory();
    	contents.add(of.createGetTermInfo(termInfoRequest));
    	
		String answer = sendQuery(MessageFactory.createRequestMessage(messageBody, security, projectId), 2);
		
		log.debug("Got Modifier Info as answer. Check if folder or looping is needed");
		try {
    		ResponseMessageType responseMsg = MessageFactory.unmarshal(answer, ResponseMessageType.class).getValue();
    		ConceptsType conceptSet = ((JAXBElement<ConceptsType>)responseMsg.getMessageBody().getAny().get(0)).getValue();
    		ConceptType conceptInfo = conceptSet.getConcept().get(0);
    		AdditionalDataHelper.ModContainer container = new AdditionalDataHelper.ModContainer();
    		
    		container.appliedPath =  appliedPath;
    		
    		if (conceptInfo.getVisualattributes().contains("DA")) {
    			container.content = conceptInfo.getName();
				modNames.put(conceptInfo.getDimcode(), container);
				log.debug("Folder! Adding Concept: " + conceptInfo.getDimcode() + " IS " + container.content);
    		} else if (conceptInfo.getLevel() == 1) {
    			// Max Level is reached. Fake a folder for although it is a modifier item
    			// This happens if modifier like patientId, age or else (filled with distinct numerical)
    			// values are used: the may have a parent CONCEPT not a parent DA!
    			
    			container.content = conceptInfo.getName();
    			modNames.put(conceptInfo.getDimcode(), container);
    			log.debug("Fake-Folder! Addding Concept: " + conceptInfo.getDimcode() + " IS " + container.content);
    		
    		} else {
    			String newPath = conceptInfo.getKey();
    			int idx = newPath.lastIndexOf("\\", newPath.length()-2)+1;
    			newPath = newPath.substring(0, idx);
    		
    			String newDim = newPath.replaceFirst("\\\\\\\\(.*?)\\\\", "\\\\");
    			if (!modNames.containsKey(newDim)) {
    			 	termInfoRequest.setSelf(newPath);
					contents.clear();
					contents.add(of.createGetTermInfo(termInfoRequest));
					answer = sendQuery(MessageFactory.createRequestMessage(messageBody, security, projectId), 2);
					responseMsg = MessageFactory.unmarshal(answer, ResponseMessageType.class).getValue();
		    		conceptSet = ((JAXBElement<ConceptsType>)responseMsg.getMessageBody().getAny().get(0)).getValue();
		    		conceptInfo = conceptSet.getConcept().get(0);
		    		
		    		container.content = conceptInfo.getName();
		    		modNames.put(conceptInfo.getDimcode(), container);
		    		log.debug("Folder!: Adding Concept: " + conceptInfo.getDimcode() + " IS " + container.content);
    			}
    		}
		} catch (Exception ex) {
			log.error("Exception in ModifierInfo. Lines 260 - 290");
			throw new I2B2Exception(ex.toString());
		}	
	}
	
	@SuppressWarnings("unchecked")
	public String getConceptName(String conceptPath) throws I2B2Exception {
		log.debug("Data for a FA Concept is required!");
    	BodyType messageBody = new BodyType();
    	List<Object> contents = messageBody.getAny();
    	
    	GetTermInfoType termInfoRequest = new GetTermInfoType();
    	termInfoRequest.setBlob(true);
    	termInfoRequest.setType("core");
    	termInfoRequest.setSynonyms(false);
    	termInfoRequest.setHiddens(true);
    	termInfoRequest.setMax(300);
    	termInfoRequest.setSelf(conceptPath);
    	
    	
    	// We are interested in the name of the Folder containing this concept: go one level higher in the hierarchy
    	//int pos = conceptPath.lastIndexOf("\\", conceptPath.length()-2)+1;
    	//termInfoRequest.setSelf(conceptPath.substring(0, pos));
    	
    	edu.goettingen.idrt.additionalData.datavo.crcontmessage.ObjectFactory of =
    	new edu.goettingen.idrt.additionalData.datavo.crcontmessage.ObjectFactory();
    	contents.add(of.createGetTermInfo(termInfoRequest));
    	
		String answer = sendQuery(MessageFactory.createRequestMessage(messageBody, security, projectId), 2);
		
		log.debug("Got ConceptFolder Info as answer.");
		try {
    		ResponseMessageType responseMsg = MessageFactory.unmarshal(answer, ResponseMessageType.class).getValue();
    		ConceptsType conceptSet = ((JAXBElement<ConceptsType>)responseMsg.getMessageBody().getAny().get(0)).getValue();
    		ConceptType conceptInfo = conceptSet.getConcept().get(0);
    		
    		return conceptInfo.getName();
		} catch (Exception ex) {
			log.error("Exception while getting ConceptFolder Name");
			throw new I2B2Exception(ex.toString());
		}	
	}
	
	public String sendFullMessageToCRC(OMElement input) throws I2B2Exception {
		OMElement answer;
		
		try {
			sender.getOptions().setTo(new EndpointReference(pdoUrl));
			answer = sender.sendReceive(input);
		} catch (AxisFault ex) {
			log.error("Exception on Refinement Query. Lines 301 - 302");
			throw new I2B2Exception(ex.toString());
		}
				 
	    return answer.toString();
	}

	public void setSecurity(SecurityType security2) {
		security = security2;
	}
	
	public void setProjectId(String id) {
		projectId = id;
	}
}