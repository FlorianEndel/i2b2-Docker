package edu.goettingen.idrt.additionalData.util;

import javax.xml.bind.annotation.XmlAttribute;
public class AdditionalDataObservation {
	private String patientId;
	private String eventId;
	private String instanceNum;
	private String value;
	private String startDate;
	private String endDate;
	
	public String getPatientId() { return patientId;}
	public String getEventId() { return eventId; }
	public String getInstanceNum() { return instanceNum; }
	public String getValue() { return value; }
	public String getStartDate() { return startDate; }
	public String getEndDate() { return endDate; }
	
	@XmlAttribute(name="id")
	public void setPatientId(String id) { patientId = id; }
	
	@XmlAttribute(name="eventId")
	public void setEventId(String id) { eventId = id; }
	
	@XmlAttribute(name="instanceNum")
	public void setInstanceNum(String num) { instanceNum = num; }
	
	@XmlAttribute(name="value")
	public void setValue(String val) { value = val; }
	
	@XmlAttribute(name="startDate")
	public void setStartDate(String date) { startDate = date; }
	
	@XmlAttribute(name="endDate")
	public void setEndDate(String date) { endDate = date; }
}
