package edu.goettingen.idrt.additionalData.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;

import edu.goettingen.idrt.additionalData.util.MessageFactory;
import edu.goettingen.idrt.additionalData.util.AdditionalDataColumn;
import edu.goettingen.idrt.additionalData.util.AdditionalDataObservation;
import edu.goettingen.idrt.additionalData.util.AdditionalDataPid;
import edu.goettingen.idrt.additionalData.util.AdditionalDataPidList;
import edu.goettingen.idrt.additionalData.util.AdditionalDataTab;
import edu.goettingen.idrt.additionalData.util.QueryDefinition;
import edu.harvard.i2b2.common.exception.I2B2Exception;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.ItemType;
import edu.goettingen.idrt.additionalData.datavo.crcpdomessage.PanelType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.BodyType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.InfoType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.ResponseHeaderType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.ResponseMessageType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.ResultStatusType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.SecurityType;
import edu.goettingen.idrt.additionalData.datavo.i2b2message.StatusType;
import edu.goettingen.idrt.additionalData.datavo.pdo.BlobType;
import edu.goettingen.idrt.additionalData.datavo.pdo.ConceptType;
import edu.goettingen.idrt.additionalData.datavo.pdo.ModifierType;
import edu.goettingen.idrt.additionalData.datavo.pdo.ObservationSet;
import edu.goettingen.idrt.additionalData.datavo.pdo.ObservationType;
import edu.goettingen.idrt.additionalData.datavo.pdo.PatientDataType;
import edu.goettingen.idrt.additionalData.datavo.pdo.PidType;

import org.apache.axiom.om.OMElement;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class AdditionalDataHelper {
	private static Log log = LogFactory.getLog(AdditionalDataHelper.class);

	private CRCMessagingUtil crcUtil;
	private SecurityType security;
	private String projectId;
	private String resultId;
	private HashMap<String, String> conceptNames;
	private HashMap<String, ModContainer> modifierNames;
	private HashMap<String, String> valueTypeOfConcept;
	private ArrayList<HashMap<String, HashSet<String>>> instanceNumInfoMap;
	
	//private StopWatch stopWatch = new StopWatch("Debug Stop Watch");
	private class StringContainer {
		public String main;
		public String sub;
	}
	
	public static class ModContainer {
		public String content;
		public String appliedPath;
	}

	public AdditionalDataHelper(SecurityType security, String projectId, String url) throws I2B2Exception {
		this.security = security;		// Security needed for legal CRC Querys
		this.projectId = projectId;		// ProjectId for accessing correct project
		this.resultId = "";				// ResultId for using a specific patientSet
		this.conceptNames = new HashMap<String, String>();
		this.modifierNames = new HashMap<String, ModContainer>();
		this.valueTypeOfConcept = new HashMap<String, String>();
		this.instanceNumInfoMap = new ArrayList<HashMap<String, HashSet<String>>>();
		crcUtil = new CRCMessagingUtil(security, projectId, url);	// Util-class for communication with CRC-Cell
	}
	
	public PatientDataType getResponseForQueryMasterId(String queryMasterId, String queryResultId) throws I2B2Exception {	
		// Just saving the resultId (needed later in program) and ordering the calls to the CRC Cell 
		// Works as a structering layer and hides program code from the executor runnable.
		resultId = queryResultId;
		
		log.debug("MOREDATA: MAINSTEP: Calling SendToCRC Function for QueryId from Helper Class");
		String response = crcUtil.sendQMMessageToCRC(queryMasterId);
		
		log.debug("MOREDATA: MAINSTEP: Extracting Request XML from CRC Answer.");
		QueryDefinition requestXml = crcUtil.extractRequestXML(response);
		
		// Nutze weiterhin concept_set_using_filter_list bei CRC Call (erspart 1000000 GetTermInfo hoffentlich)
		// Nutze dort BaseCode => Concept.CD von ResponseXML. ueber BaseCode ItemKey nachgucken.
		// ItemKey in Hashmap nachgucken, name den ganzen weg zuruecksenden. als columnHeader abspeichern
		// Viel Arbeit nur fuer eye candy :(
		evaluateRequest(requestXml);
		
		log.debug("MOREDATA: MAINSTEP: Calling SendToCRC Function for Request from Helper Class");
		response = crcUtil.sendXMLMessageToCRC(requestXml, queryResultId);
		
		log.debug("MOREDATA: MAINSTEP: Extracting PatientData from CRC Answer.");
		PatientDataType patientData = crcUtil.extractPatientData(response);
		
		return patientData;
	}
		
	/*
	 * For every item, the item name is stored, e.g. mild dementia
	 * If the item is not a folder, the folder name is retrieved form the items tooltip
	 * These values are then stored with the item-Key in a HashMap
	 */
	private void evaluateRequest(QueryDefinition requestXml) throws I2B2Exception {
		List<PanelType> requestList = requestXml.getPanel();
		for (int i = 0; i < requestList.size(); i++) {
			log.debug("AA: A panel");
			List<ItemType> itemList = requestList.get(i).getItem();
			for (int j = 0; j < itemList.size(); j++) {
				log.debug("AA: A item");
				ItemType item = itemList.get(j);
				
				String itemName;
				String itemConcept;
				
				if (item.getItemIcon().equals("LA")) {
					log.debug("AA: Its a LA ITEM");
					String folderName = item.getItemKey();
					int pos = folderName.lastIndexOf("\\", folderName.length()-2)+1;
					itemConcept = folderName.substring(0, pos);
					itemName = crcUtil.getConceptName(itemConcept);
				} else {
					log.debug("AA: Its a FA ITEM");
					itemName = item.getItemName();
					itemConcept = item.getItemKey();
				}
				
				log.debug("REGEX");
				itemConcept = itemConcept.replaceFirst("\\\\\\\\(.*?)\\\\", "\\\\");
				log.debug("REGEX FINISHED");
				
				conceptNames.put(itemConcept, itemName);
				
				//Get all the modifiers
				ItemType.ConstrainByModifier modifier = item.getConstrainByModifier();
				if (modifier != null) {
					log.debug("IT HAZ A MODIFIER");
					String modifierKey = modifier.getModifierKey();
					String appliedPath = modifier.getAppliedPath();
					crcUtil.getDaModifierName(modifierKey, appliedPath, modifierNames);
					log.debug("MODIFIER FINISHED");
				}
				
			}
		}
	}
	
	/*
	 * This function does the main work
	 * It takes the response, converts it to a more lightweight format
	 * and creates an answer separated into different tabs, with 
	 * number one being patient data and any additional being modifier data 	
	 */
	public OMElement evaluateResponse(PatientDataType response) throws I2B2Exception {
		// Create the List of Tab (JAXB 'Root' Class)
		List<Object> eval = new ArrayList<Object>();
				
		/* |||||||||||||||||||||||||||||||||||| */
		/* || CONVERT CONCEPT & MODIFIER SET || */
		/* |||||||||||||||||||||||||||||||||||| */
		
		log.debug("MOREDATA: Converting Concept List");
		// In this step, the concept List is converted to a HashMap to allow
		// much faster access to the path values linked with the conceptCDs
		HashMap<String, StringContainer> conceptToPath = new HashMap<String, StringContainer>();
		List<ConceptType> conceptList = response.getConceptSet().getConcept();
		
		for (int i = 0; i < conceptList.size(); i++) {
			ConceptType concept = conceptList.get(i);
			StringContainer def = new StringContainer();
			def.main = concept.getConceptPath();
			def.sub = concept.getNameChar();
			conceptToPath.put(concept.getConceptCd(), def);
		}
		
		log.debug("MOREDATA: Converting Modifier List");
		// The same step as before is repeated but with modifier in mind
		// also we need less data: the modifier_cd and its name_char
		HashMap<String, String> modifierCdToModifierPath = new HashMap<String, String>();
		List<ModifierType> modifierList = response.getModifierSet().getModifier();
		
		for (int i = 0; i < modifierList.size(); i++) {		
			ModifierType modifier = modifierList.get(i);
			
			modifierCdToModifierPath.put(modifier.getModifierCd(), modifier.getModifierPath());
			log.debug("MDMODLOOP: Adding " + modifier.getModifierCd() + " WITH " + modifier.getModifierPath() );
		}
		
		/* |||||||||||||||||||||||||||||||||||| */
		/* || CONVERTING OF THE OBSERVATIONS || */
		/* |||||||||||||||||||||||||||||||||||| */

		log.debug("MOREDATA: JAJA Begin: Transform i2b2 Observation to moreData Observation (less bulk data)");
		List<ObservationSet> observationSets = response.getObservationSet();
		
		// First: Create an complex structure (sadly) for the ALL tabs:
		// Difference Between Panels (ArrayList), Different Modifier (Outer HashMap) [@=PatientData],
		// Different Concept of 1 Modifier (Middle HashMap), Observations for this Concept
		// listed by PID (Inner HashMap)
		ArrayList<HashMap<String, HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>>>> modTabSet =
				new ArrayList<HashMap<String, HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>>>>();
		
		// Now iterate over each Panel [returned as observation sets]
		for (ObservationSet obsSet : observationSets) {
			// Create one modTab-structure for this panel, Description above.
			HashMap<String, HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>>> rawModTab =
					new HashMap<String, HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>>>();
			
			// Get the raw returned i2b2-Observations
			List<ObservationType> i2b2Observations = obsSet.getObservation();
			
			// Create new HashMap for current Panel for future retaining of instance nums
			instanceNumInfoMap.add(new HashMap<String, HashSet<String>>());
			
			for (ObservationType i2b2Observation : i2b2Observations) {
				// Convert any i2b2Observation into a MoreDataObservation. It's a less complex class.
				AdditionalDataObservation observation = new AdditionalDataObservation();
				observation.setPatientId(i2b2Observation.getPatientId().getValue());
				observation.setEventId(i2b2Observation.getEventId().getValue());
				observation.setInstanceNum(i2b2Observation.getInstanceNum().getValue());
				observation.setStartDate(String.valueOf(i2b2Observation.getStartDate()));
				observation.setEndDate(String.valueOf(i2b2Observation.getEndDate()));
				
				// Retrieve the used Concept
				String orgConcept = i2b2Observation.getConceptCd().getValue();
				StringContainer def = conceptToPath.get(orgConcept);
				String concept = def.main; // This cannot be null.
				
				int length = 0;
				String usedConcept = "";
				
				log.debug("MDLOOP: ------------------------------");
				for (String searchedConcept : conceptNames.keySet()) {
					if (concept.contains(searchedConcept) && searchedConcept.length() > length) {
						usedConcept = searchedConcept;
						length = searchedConcept.length();
					}
				}
				
				concept = usedConcept;
				log.debug("MDLOOP: Concept USED " + concept);
				
				// Check which value is used and add it to the moreDataObservation
				String valueType = i2b2Observation.getValuetypeCd();
				if (valueType == null) {
					BlobType obsBlob = i2b2Observation.getObservationBlob();
					if (obsBlob != null && obsBlob.getContent().size() != 0) {
						observation.setValue(obsBlob.getContent().get(0).toString());
						valueType = "t";
					} else {
						observation.setValue(def.sub);
						valueType = "-";
					}
				}
				else if (valueType.equals("T")) {
					observation.setValue(i2b2Observation.getTvalChar());
					valueType = "t";
				}
				else if (valueType.equals("N")) {
					observation.setValue(i2b2Observation.getNvalNum().getValue().toString());
					valueType = "n";
				}
				
				log.debug("MDLOOP: Value USED " + observation.getValue() + " WITH valType " + valueType );
				
				String modifier = i2b2Observation.getModifierCd().getValue();
				log.debug("MDLOOP: Modifier IS " + modifier);
				
				// If Obs is a Modifier: make Concept the modGroup and get the "real" modConcept.
				if (!modifier.equals("@")) {
									
					String tmp = modifier;
					modifier = concept;
					
					String path = modifierCdToModifierPath.get(tmp);
					if (modifierNames.keySet().contains(path)) concept = path;
					else {
						length = 0;
						concept = "Undefined";
						for (String candidat : modifierNames.keySet()) {
							if (candidat.length() > length && path.contains(candidat)) {
								concept = candidat;
								length = candidat.length();
							}
						}
					}
						
					log.debug("MDLOOP: concept SETTO " + concept);
					
					// Save instanceNums sorted by AppliedPath for use in Retaining Step
					String num = i2b2Observation.getInstanceNum().getValue();
					ModContainer modData = modifierNames.get(concept);
					String apPath = modData.appliedPath;
					
					// Set value type for empty modifiers to there modifier name instead of concept-obs-name TODO: test if valid
					if (valueType.equals("-")) {observation.setValue(modData.content);}
					
					HashMap<String, HashSet<String>> instanceNumInfo = instanceNumInfoMap.get(instanceNumInfoMap.size()-1);
					if (!instanceNumInfo.containsKey(apPath)) {
						instanceNumInfo.put(apPath, new HashSet<String>());
					}
					
					instanceNumInfo.get(apPath).add(num);
				}
				
				addToModifierTab(rawModTab, modifier, observation, concept, valueType);
			}
			
			// At the end add the concept-column to the list of all columns.
			modTabSet.add(rawModTab);
		}
	
		// The Next target remove all PID-Observations that arent shown in all panels.
		// This implements the mechanic of AND. But: in the panels it should be possible
		// to have some PIDs only in one concept-column and not in the other. This implements
		// the OR mechanism working in one panel.
		// Note: If a patientSet instead of a QM-Query this part can be skipped: the patientset
		// gives us only the patients matching all our conditions.
		
		
		/*log.debug("BEGIN DATA DUMPING");
		for (int i = 0; i < modTabSet.size(); i++) {
			HashMap<String, HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>>> sameModPanel = modTabSet.get(i);
			log.debug("MODTABSET " + i);
			
			for (String columnName : sameModPanel.keySet()) {
				log.debug("   COLUMNNAME: " + columnName);
				HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>> columnOneMod = sameModPanel.get(columnName);
				
				for (String modName : columnOneMod.keySet()) {
					log.debug("      MODNAME: " + modName);
					HashMap<String, ArrayList<AdditionalDataObservation>> obsOneColumn = columnOneMod.get(modName);
					
					for (String pid : obsOneColumn.keySet()) {
						log.debug("         PID: " + pid);
					}
				}
			}
		}
		log.debug("END DATA DUMPING");*/
		
		// Reduce number of instanceNums according to appliedPath so that only "instances will be the same" are stored
		log.debug("Determine allowed InstanceNums per AppliedPath");
		HashMap<String, HashSet<String>> savior = instanceNumInfoMap.get(0);
		for (int i = 1; i < instanceNumInfoMap.size(); i++) {
			HashMap<String, HashSet<String>> challenger = instanceNumInfoMap.get(i);
			for (String apPath : challenger.keySet()) {
				HashSet<String> resolution = challenger.get(apPath);
				if (savior.containsKey(apPath)) {
					savior.get(apPath).retainAll(resolution);
				} else {
					savior.put(apPath, resolution);
				}
			}
		}
		log.debug("Finished Determining");
		
		// Go through every modifier and get the allowed instanceNums for this modifier calculated earlier
		// Then check for every AdditionalDataObservation if its instanceNum is allowed
		// If not remove the AdditionalDataObservation from the List of Observations
		log.debug("Begin to remove instanceNums that are not allowed");
		for (int i = 0; i < modTabSet.size(); i++) {
			for (String conceptPath : modTabSet.get(i).keySet()) {	
				if (conceptPath.equals("@")) continue;
				log.debug("Working with Concept: " + conceptPath);
				Iterator<Map.Entry<String, HashMap<String, ArrayList<AdditionalDataObservation>>>> modTabIterator = modTabSet.get(i).get(conceptPath).entrySet().iterator();
				
				while (modTabIterator.hasNext()) {
					log.debug("Next Modifier");
					Map.Entry<String, HashMap<String, ArrayList<AdditionalDataObservation>>> next = modTabIterator.next();
					String modifierPath = next.getKey();
					log.debug("HAS PATH: " + modifierPath);
					ModContainer a = modifierNames.get(modifierPath);
					String appliedPath = a.appliedPath;
					log.debug("HAS APPLIED PATH: " + appliedPath);
					HashSet<String> allowedInstanceNums = savior.get(appliedPath);
					HashMap<String, ArrayList<AdditionalDataObservation>> observationsByPidPerSingleModifierPath = next.getValue();
					Iterator<Map.Entry<String, ArrayList<AdditionalDataObservation>>> modPathIterator = observationsByPidPerSingleModifierPath.entrySet().iterator();
					
					while (modPathIterator.hasNext()) {
						ArrayList<AdditionalDataObservation> observationListForSinglePid = modPathIterator.next().getValue();
						Iterator<AdditionalDataObservation> listIterator = observationListForSinglePid.iterator();
						
						while (listIterator.hasNext()) {
							AdditionalDataObservation singleObservation = listIterator.next();
							if (!allowedInstanceNums.contains(singleObservation.getInstanceNum())) {
								log.debug("DEL instNUM: " + singleObservation.getInstanceNum());
								listIterator.remove();
							}
						}
						//empty-check
						if (observationListForSinglePid.isEmpty()) modPathIterator.remove();
					}
					//empty-check
					if (observationsByPidPerSingleModifierPath.isEmpty()) modTabIterator.remove();
				}
				//TODO: do we really need more empty check beyond this point?
			}
		}
		log.debug("Finished removing unallowed InstanceNums");
		
		log.debug("Retaining the ObsSets against each other."); 
		if (resultId.equals("")) {
			
			ArrayList<HashSet<String>> orPidLists = new ArrayList<HashSet<String>>();
			
			
			
			// Any Pid listed in this Panel is combined using an OR behavior, this means that
			// no pid is deleted in this step. A HashSet is used to save every used pid only once!
			for (int i = 0; i < modTabSet.size(); i++) {
				//HashMap<String, HashMap<String, MoreDataObservation>> singlePanel = rawColumnsPerPanel.get(i);
				HashMap<String, HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>>> sameModPanel = modTabSet.get(i);
				
				// Add all Patient-Data-Tabs from this Panel to the PID List
				HashSet<String> orPidList = new HashSet<String>();
				
				
				
				// Do the same for ALL Modifier Tabs from this Panel
				for (HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>> columnOneMod : sameModPanel.values()) {
					for (HashMap<String, ArrayList<AdditionalDataObservation>> obsOneColumn : columnOneMod.values()) {
						orPidList.addAll(obsOneColumn.keySet());
					}
				}
				
				orPidLists.add(orPidList);
			}
			
			// These Step will remove from the first PidList any PID that are not contained in
			// any other PidList. This reflects the AND-behavior between different Panels
			HashSet<String> pidList = orPidLists.get(0);
			for (int i = 1; i < orPidLists.size(); i++) {
				pidList.retainAll(orPidLists.get(i));
			}
			
			// Instantly stuff the PIDList in the MoreData answer
			ArrayList<AdditionalDataPid> pids = new ArrayList<AdditionalDataPid>();
			List<PidType> i2b2PidList = response.getPidSet().getPid();
			
			for (int i = 0; i < i2b2PidList.size(); i++) {
				String hivePid = i2b2PidList.get(i).getPatientId().getValue();
				if (pidList.contains(hivePid)) {
					AdditionalDataPid pid = new AdditionalDataPid();
					pid.setPid(hivePid);
					
					// Mapped Pid can be null
					if (i2b2PidList.get(i).getPatientMapId().size() > 0) {
						pid.setMappedPid(i2b2PidList.get(i).getPatientMapId().get(0).getValue());
					} else {
						pid.setMappedPid(hivePid);
					}
					
					pids.add(pid);
				}
			}
			
			AdditionalDataPidList finalPidList = new AdditionalDataPidList();
			finalPidList.getPidList().addAll(pids);
			eval.add(finalPidList);
			
			//TODO: Does the following function do anything useful?
			// Repeat the same steps for Modifier
			for (HashMap<String, HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>>> onePanel : modTabSet) {
				for (HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>> columnOneMod : onePanel.values()) {
					for (HashMap<String, ArrayList<AdditionalDataObservation>> obsOneColumn : columnOneMod.values()) {
						obsOneColumn.keySet().retainAll(pidList);
					}
				}
			}
		} else {
			// If PatientSet-Query CRC will deliver a PID-List. This list
			// is complete and will simply be copied.
			ArrayList<AdditionalDataPid> pidList = new ArrayList<AdditionalDataPid>();
			List<PidType> i2b2PidList = response.getPidSet().getPid();
			
			for (int i = 0; i < i2b2PidList.size(); i++) {
				AdditionalDataPid pid = new AdditionalDataPid();
				pid.setPid(i2b2PidList.get(i).getPatientId().getValue());
				pid.setMappedPid(i2b2PidList.get(i).getPatientMapId().get(0).getValue());
				pidList.add(pid);
			}
			
			AdditionalDataPidList pids = new AdditionalDataPidList();
			pids.getPidList().addAll(pidList);
			eval.add(pids);
		}
		log.debug("Finished Removing unwanted patients");
		
		//After achieving this pure panels all left to do is cycling through the data and putting them into MoreDataColumns
		log.debug("Beginning to convert structure");
		
		// MainStep: Dump Modifier Working Structure into output structure
		HashMap<String, HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>>> converter = modTabSet.get(0);
		
		// First step is dissolving the panel structure.
		// Converter Class will be used as a temporal storage.
		// This Loops unite all Panels with another
		// If existing, same modifiers or panels or observations will be put in one list
		// !!! In best and most cases, the outer loop will just trigger the ELSE-Statement and nothing else. !!!
		for (int i = 1; i < modTabSet.size(); i++) {
			HashMap<String, HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>>> listOfModifiersForOnePanel = modTabSet.get(i);
			for(String singleModifierKey : listOfModifiersForOnePanel.keySet()) {	
				HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>> listOfColumnsForOneModifier = listOfModifiersForOnePanel.get(singleModifierKey);
				if (converter.containsKey(singleModifierKey)) {
					HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>> columnConverter = converter.get(singleModifierKey);			
					for (String singleColumnKey : listOfColumnsForOneModifier.keySet()) {
						HashMap<String, ArrayList<AdditionalDataObservation>> listOfObservationsForOneColumn = listOfColumnsForOneModifier.get(singleColumnKey);
						if (columnConverter.containsKey(singleColumnKey)) {
							HashMap<String, ArrayList<AdditionalDataObservation>> observationConverter = columnConverter.get(singleColumnKey);
							for (String singleObservationKey : listOfObservationsForOneColumn.keySet()) {
								ArrayList<AdditionalDataObservation> singleObsList = listOfObservationsForOneColumn.get(singleObservationKey);
								if (observationConverter.containsKey(singleObservationKey)) {
									observationConverter.get(singleObservationKey).addAll(singleObsList);
									//uniteDuplicates(observationConverter.get(singleObservationKey), singleObservation);
								} else {
									observationConverter.put(singleObservationKey, singleObsList);
								}
							}
						} else {
							columnConverter.put(singleColumnKey, listOfObservationsForOneColumn);
						}
					}
				} else {
					converter.put(singleModifierKey, listOfColumnsForOneModifier);
				}
			}	
		}
		
		log.debug("Finished converting Structure");
		
		// Second step: Convert converter structure to response structure
		int id = 1;
		for (String modName : converter.keySet()) {
			AdditionalDataTab modTab = new AdditionalDataTab();
			
			// Gives Patient Data the matching Name and front ID
			if (modName.equals("@")) {
				modTab.setTabName("Patient Data");
				modTab.setId("0");
			} else {
				modTab.setTabName(conceptNames.get(modName));
				modTab.setId(String.valueOf(id));
				id++;
			}
			
			List<AdditionalDataColumn> modTabColumns = modTab.getColumns();
			HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>> rawModColumns = converter.get(modName);
			
			for (String columnName : rawModColumns.keySet()) {
				AdditionalDataColumn modTabColumn = new AdditionalDataColumn();
				log.debug("KANU: Searching for concept name WITH " + columnName);
				if (columnName.equals("Undefined")) {
					modTabColumn.setHeader(columnName);
					log.debug("MDNAME: Tab name is UNDEFINED");
				} else if (modTab.getId().equals("0")) {
					modTabColumn.setHeader(conceptNames.get(columnName));
					log.debug("MDNAME: For Patientdata, USED " + columnName + " FOUND " + modTabColumn.getHeader());
				} else {
					modTabColumn.setHeader(modifierNames.get(columnName).content);
					log.debug("MDNAME: For ModifierTab, USED " + columnName + " FOUND " + modTabColumn.getHeader());
				}
				//String repName = modTab.getId().equals("0") ? conceptNames.get(columnName) : modifierNames.get(columnName).content;
				//modTabColumn.setHeader(repName);
				modTabColumn.setValueType(valueTypeOfConcept.get(columnName));
				for (ArrayList<AdditionalDataObservation> obsList : rawModColumns.get(columnName).values()) {
					modTabColumn.getObservations().addAll(obsList);
				}
				//modTabColumn.getObservations().addAll(rawModColumns.get(columnName).values();
				modTabColumns.add(modTabColumn);
			}
			
			eval.add(modTab);
		}
		
		log.debug("MOREDATA: MEH Successfully created the moreData Answer structure");
		
		try {
			return createXmlMessage(eval);
		} catch (XMLStreamException e) {
			throw new I2B2Exception(e.toString());
		}
	}
	
	private void addToModifierTab(HashMap<String, HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>>> modTabSet, String modName, AdditionalDataObservation modObservation, String columnName, String valueType) {
		// Check if Tab (identified by TabName) does currently exists - if not, create.
		if (!modTabSet.containsKey(modName)) {
			modTabSet.put(modName, new HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>>());
		}
		HashMap<String, HashMap<String, ArrayList<AdditionalDataObservation>>> modTab = modTabSet.get(modName);
		
		// Check if Column for Concept (identified by ConceptCD) exists in Tab - if not, create.
		if (!modTab.containsKey(columnName)) {
			modTab.put(columnName, new HashMap<String, ArrayList<AdditionalDataObservation>>());
			valueTypeOfConcept.put(columnName, valueType);
		}
		
		// Add the Observation to the matching Column and Tab
		HashMap<String, ArrayList<AdditionalDataObservation>> modColumn = modTab.get(columnName);
		String pidForObs = modObservation.getPatientId();
		if (modColumn.containsKey(pidForObs)) {
			modColumn.get(pidForObs).add(modObservation);
		} else {
			ArrayList<AdditionalDataObservation> obsList = new ArrayList<AdditionalDataObservation>();
			obsList.add(modObservation);
			modColumn.put(pidForObs, obsList);
		}
	}
	
	private OMElement createXmlMessage(List<Object> eval) throws I2B2Exception, XMLStreamException {
		log.debug("MOREDATA: Transforming Answer into XML String Object ...");
		ResponseMessageType response = new ResponseMessageType();
		
		response.setMessageHeader(MessageFactory.createMessageHeader(security, projectId));
		response.setRequestHeader(MessageFactory.createRequestHeader());
		
		ResponseHeaderType responseHeader = new ResponseHeaderType();
		
		InfoType info = new InfoType();
		info.setValue("Log information");
		responseHeader.setInfo(info);
		
		ResultStatusType status = new ResultStatusType();
		StatusType s = new StatusType();
		s.setType("DONE");
		s.setValue("DONE");
		status.setStatus(s);
		responseHeader.setResultStatus(status);
		
		response.setResponseHeader(responseHeader);
		log.debug("Finished building ALL THE headers...");

		BodyType responseBody = new BodyType();
		responseBody.getAny().addAll(eval);
		response.setMessageBody(responseBody);
		log.debug("Added moreData-Data to message Body. Beginning converting!");
		
		return MessageFactory.createOMElement(response);
	}

	public PatientDataType getResponseForQuery(OMElement input) throws I2B2Exception {
		// Save concept and modifier names of the request
		log.debug("ZZZ: "  + input.toString());
		
		OMElement item = input.getFirstChildWithName(new QName("message_body"));
		log.debug("AAA");
		
		@SuppressWarnings("rawtypes")
		Iterator it = item.getChildElements();
		while (it.hasNext()) {
			OMElement ele = (OMElement) it.next();
			log.debug("A: " + ele.getQName().toString());
		}
		
		item = item.getFirstChildWithName(new QName("http://www.i2b2.org/xsd/cell/crc/pdo/1.1/","request"));
		log.debug("BBB");
		log.debug(item.toString());
		item = item.getFirstChildWithName(new QName("filter_list"));
		log.debug("CCC");
		item = item.getFirstChildWithName(new QName("panel"));
		log.debug("DDD");
		item = item.getFirstChildWithName(new QName("item"));
		log.debug("EEE");
		
		String conceptKey = item.getFirstChildWithName(new QName("item_key")).getText();
		log.debug("FFF");
		String conceptName; 
		log.debug("GGG");
				
		if (item.getFirstChildWithName(new QName("item_icon")).getText().equals("FA")) {
			// Item is already a folder: just add the already known concept name
			conceptName = item.getFirstChildWithName(new QName("item_name")).getText();
		} else {
			// Item is an item: add the name of the folder containing it
			// In this case we just save the conceptKey itself. In normal case we save the conceptkey of its folder.
			// what to use?
			
			
			// Changed to match required input
			int pos = conceptKey.lastIndexOf("\\", conceptKey.length()-2)+1;
			String send = conceptKey.substring(0, pos);
			conceptName = crcUtil.getConceptName(send);
		}
		
		conceptKey = conceptKey.replaceFirst("\\\\\\\\(.*?)\\\\", "\\\\");
		log.debug("HHH");
		
		conceptNames.put(conceptKey, conceptName);
		
		
		OMElement modifier = item.getFirstChildWithName(new QName("constrain_by_modifier"));
		if (modifier != null) {
			
			// Query the modifier
			String modifierKey = modifier.getFirstChildWithName(new QName("modifier_key")).getText();
			String appliedPath = modifier.getFirstChildWithName(new QName("applied_path")).getText(); //TODO: correct?
			crcUtil.getDaModifierName(modifierKey, appliedPath, modifierNames);
		}
		
		// Send message, extract data
		String response = crcUtil.sendFullMessageToCRC(input);
		return crcUtil.extractPatientData(response);
	}
}