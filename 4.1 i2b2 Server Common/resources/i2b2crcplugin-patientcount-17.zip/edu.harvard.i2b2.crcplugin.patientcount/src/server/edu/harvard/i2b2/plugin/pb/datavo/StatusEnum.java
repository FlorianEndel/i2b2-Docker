package edu.harvard.i2b2.plugin.pb.datavo;

public enum StatusEnum {

	FILLER, QUEUED, PROCESSING, FINISHED, ERROR, INCOMPLETE, COMPLETED;

}
