package edu.harvard.i2b2.plugin.pb.dao;

public interface IDAOFactory {

	public SetFinderDAOFactory getSetFinderDAOFactory();

}
