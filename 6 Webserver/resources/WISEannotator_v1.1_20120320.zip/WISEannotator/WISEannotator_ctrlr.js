/*==============================================================================================================================================================================================
 * @projectDescription	Workplace Items Sharing Enhancement - Tagger (Tool for tagging items in the Workplace with useful information).
 * @inherits		        i2b2
 * @namespace		i2b2.WISEannotator
 * @author		        S. Wayne Chan, Biomedical Research Informatics Development Group (BRIDG) and Biomedical Research Informatics Consulting & Knowledge Service (BRICKS),
 *                                     Div. of Health Informatics and Implementation Science (HIIS), Dept. of Quantitative Health Sciences (QHS), 
 *                                     University of Massachusetts Medical School (UMMS), Worcester, MA
 * @version 		        1.1 (for i2b2 v1.3 - v1.6.0.2)
 * @acknowledgement   This module leveraged off the construct / format /style / template used in the i2b2 web client plugin examples by N. Benik & G. Weber
 * --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * @copyright		        Copyright 2011, 2012 University of Massachusetts Medical School.
 * @license/disclaimer    This file is part of WISE-Annotator plugin for the i2b2 webclient.
 *
 *			WISE-Annotator plugin for the i2b2 webclient is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published
 *			by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
 *
 *			WISE-Annotator plugin for the i2b2 webclient is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *			MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 *
 *			You should have received a copy of the GNU General Public License along with WISE-Annotator plugin for the i2b2 webclient.  If not, see <http://www.gnu.org/licenses/>.
 * --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 * updated history (dateformat: YYYYMMDD) 
 * 20110729 S. Wayne Chan (v.1.0) developed initial version.
 * 20111028 S. Wayne Chan (v.1.0) added “copyright” & “license/disclaimer” sections in header following UMMS legal signoff.
 * 20120316 S. Wayne Chan (v.1.1) updated to add support for IE; fixed unscrollable (effectively cutoff) panel display problem on IE against i2b2 webclient v1.6.0.2.
*==============================================================================================================================================================================================
 */


// -------------------------------------------------------------------------------------------------------------------
// This method initialize this plugin
// -------------------------------------------------------------------------------------------------------------------
i2b2.WISEannotator.Init = function(loadedDiv) {
    // register DIV as valid DragDrop target for Workplace Item (WI)
    var divName = "WISEannotator-WIDROP";
    var hdlrName = "DropHandler";

    // register for drag drop events for the following data types: CONCPT, QM, QI, PRS, PRC
    var op_trgt = {dropTarget:true};
    i2b2.sdx.Master.AttachType(divName, 'WRK'   , op_trgt); // folder
    i2b2.sdx.Master.AttachType(divName, 'CONCPT', op_trgt);
    i2b2.sdx.Master.AttachType(divName, 'QM'    , op_trgt); // query
    i2b2.sdx.Master.AttachType(divName, 'QI'    , op_trgt); // query instance
    i2b2.sdx.Master.AttachType(divName, 'PRS'   , op_trgt); // patient record set
    // cannot support PRC due to WORK tends not to use the actual name (it shouldn't really matter, as not too many user is expected to put PRC into the Workplace anyway)
    //i2b2.sdx.Master.AttachType(divName, 'PRC'   , op_trgt); // patient record count
    i2b2.sdx.Master.AttachType(divName, 'PR'    , op_trgt);	
    i2b2.sdx.Master.AttachType(divName, 'QDEF'  , op_trgt);	
    i2b2.sdx.Master.AttachType(divName, 'QGDEF' , op_trgt);
    i2b2.sdx.Master.AttachType(divName, 'XML'   , op_trgt);	

    // route event callbacks to a single drop event handler used by this plugin
    var eventRouterFunc = (function(sdxData) { i2b2.WISEannotator.doDrop(sdxData); });
    i2b2.sdx.Master.setHandlerCustom(divName, 'WRK'   , hdlrName, eventRouterFunc);
    i2b2.sdx.Master.setHandlerCustom(divName, 'CONCPT', hdlrName, eventRouterFunc);
    i2b2.sdx.Master.setHandlerCustom(divName, 'QM'    , hdlrName, eventRouterFunc);
    i2b2.sdx.Master.setHandlerCustom(divName, 'QI'    , hdlrName, eventRouterFunc);
    i2b2.sdx.Master.setHandlerCustom(divName, 'PRS'   , hdlrName, eventRouterFunc);
    // cannot support PRC due to WORK tends not to use the actual name (it shouldn't really matter, as not too many user is expected to put PRC into the Workplace anyway)
    //i2b2.sdx.Master.setHandlerCustom(divName, 'PRC'   , hdlrName, eventRouterFunc);
    i2b2.sdx.Master.setHandlerCustom(divName, 'PR'    , hdlrName, eventRouterFunc);
    i2b2.sdx.Master.setHandlerCustom(divName, 'QDEF'  , hdlrName, eventRouterFunc);
    i2b2.sdx.Master.setHandlerCustom(divName, 'QGDEF' , hdlrName, eventRouterFunc);
    i2b2.sdx.Master.setHandlerCustom(divName, 'XML'   , hdlrName, eventRouterFunc);

    // initiate all model data
    i2b2.WISEannotator.Unload();

    // manage YUI tabs
    this.yuiTabs = new YAHOO.widget.TabView("WISEannotator-TABS", {activeIndex:0});
    this.yuiTabs.on('activeTabChange', function(ev) { 
	//Tabs have changed 
        if (ev.newValue.get('id')=="WISEannotator-TAB0") {
            // defer call to .doDrop()
	    //i2b2.WISEannotator.Unload();
        } else if (i2b2.WISEannotator.model.currRecord) {
	    //i2b2.h.LoadingMask.show(); // turn on the "LOADING" mask (i2b2 Query Tool "busy, please wait" display)
    	    if (ev.newValue.get('id')=="WISEannotator-TAB1") {
                if (i2b2.WISEannotator.model.resultNone && !i2b2.WISEannotator.model.targetRoot) {
                    i2b2.WISEannotator.getAnnotation();
                } // else no need to refresh, as it should have been taken care of when result was posted
	    } else if (ev.newValue.get('id')=="WISEannotator-TAB2") {
                $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-directions")[0].hide();
                $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-msgs")[0].hide();
                //alert(".Init():\nresultPending="+i2b2.WISEannotator.model.resultPending+"\nresultNone="+i2b2.WISEannotator.model.resultNone);
                if (i2b2.WISEannotator.model.targetRoot) {
	            $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-directions")[0].hide();
	            $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-noChange")[0].hide();
	            $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-msgs")[0].hide();
		    i2b2.h.LoadingMask.hide(); // turn off the "LOADING" mask (i2b2 Query Tool "busy, please wait" display)
                } else {
                    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.target-unsupported")[0].hide();
	            if (i2b2.WISEannotator.model.resultPending) {
                        i2b2.WISEannotator.updateShowResult();
                    } else if (i2b2.WISEannotator.model.resultNone) {
                        if ("" == i2b2.WISEannotator.model.currAnn || "" == i2b2.WISEannotator.model.currName) {
                            // might as well get the "Annotate" page set up also
                            //i2b2.WISEannotator.model.skipPad = true;
	                    i2b2.WISEannotator.getAnnotation();
                        } else {
                            $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-noChange")[0].show();
	                    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.target-unsupported")[0].hide();
                            i2b2.WISEannotator.showAnnotation();
                        }
                    } // else no need to refresh result
		}
	    }
            //i2b2.h.LoadingMask.hide(); // turn off the "LOADING" mask
        } else {
            $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-directions")[0].show();
            $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-noChange")[0].hide();
            $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-msgs")[0].hide();
            $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.target-unsupported")[0].hide();

            $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-resultNext")[0].hide();
            $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-unsupported")[0].hide();           
        }
    });
	
   ///swc20120315{ fix unscrollable (effectively cutoff) panel display problem on IE against i2b2 webclient v1.6.0.2 (based on v1.6.0.2 Dem1Set_ctlr.js)
    var z = $('anaPluginViewFrame').getHeight() - 34;
    $$('DIV#WISEannotator-TABS DIV.WISEannotator-MainContent')[0].style.height = z;
    $$('DIV#WISEannotator-TABS DIV.WISEannotator-MainContent')[1].style.height = z;
    $$('DIV#WISEannotator-TABS DIV.WISEannotator-MainContent')[2].style.height = z;
    $$('DIV#WISEannotator-TABS DIV.WISEannotator-MainContent')[3].style.height = z;
   ///}
};


// -------------------------------------------------------------------------------------------------------------------
// this function is called when the plugin is loaded / unloaded by the framework
// -------------------------------------------------------------------------------------------------------------------
i2b2.WISEannotator.Unload = function() {
    //alert("entered .Unload()");
    // initiate data / purge old data
    i2b2.WISEannotator.model.currRecord = false;
    i2b2.WISEannotator.model.currType = "";
    i2b2.WISEannotator.model.currName = "";
    i2b2.WISEannotator.model.currAnn = "";
    i2b2.WISEannotator.model.currKeyVal = "";
    i2b2.WISEannotator.model.wi = [];
    i2b2.WISEannotator.model.target = "";
    i2b2.WISEannotator.model.targetName = "";
    i2b2.WISEannotator.model.targetRoot = false;
    i2b2.WISEannotator.model.annLens = [];
    i2b2.WISEannotator.model.total = 0;    
    i2b2.WISEannotator.model.ann = "";
    i2b2.WISEannotator.model.resultPending = false;
    i2b2.WISEannotator.model.resultNone = true;
    i2b2.WISEannotator.model.skipPad = false;
    i2b2.WISEannotator.model.dirtyResultsData = true;
    return true;
};


// -------------------------------------------------------------------------------------------------------------------
// this function handles the user drop-in object
// -------------------------------------------------------------------------------------------------------------------
i2b2.WISEannotator.doDrop = function(sdxData) {
    i2b2.WISEannotator.Unload(); // flush everything first

    $("WISEannotator-WIDROP").style.background = "#CFB";
    sdxData = sdxData[0]; // only interested in first record
    i2b2.WISEannotator.model.currRecord = sdxData; // save the info to our local data model

    // let the user know that the drop was successful by displaying the name of the object
    $("WISEannotator-WIDROP").innerHTML = i2b2.h.Escape(sdxData.sdxInfo.sdxDisplayName);
    setTimeout("$('WISEannotator-WIDROP').style.background='#DEEBEF'", 400);	

    // optimization to prevent requerying the hive for new results if the input dataset has not changed
    i2b2.WISEannotator.model.dirtyResultsData = true;		
    //alert(".doDrop():\n\ncurrRecord="+i2b2.WISEannotator.model.currRecord+",\ndirtyResultsData="+i2b2.WISEannotator.model.dirtyResultsData+",\n!resultNone="+!i2b2.WISEannotator.model.resultNone);
};


// -------------------------------------------------------------------------------------------------------------------
// this method fetches the name, KeyValue, & starts the search for the actual Workplace Item Object
// -------------------------------------------------------------------------------------------------------------------
i2b2.WISEannotator.getAnnotation = function() {
    //alert("entered .getAnnotation() \n\ndirtyResultsData="+i2b2.WISEannotator.model.dirtyResultsData+",\nskipPad="+i2b2.WISEannotator.model.skipPad);
    i2b2.h.LoadingMask.show(); // turn on the "LOADING" mask (i2b2 Query Tool "busy, please wait" display)

    // Refresh the display with info of the SDX record that was DragDropped
    if (i2b2.WISEannotator.model.dirtyResultsData) {
	$$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-directions")[0].hide();
	$$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-msgs")[0].show();		
        $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-resultNext")[0].hide();
        $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-unsupported")[0].hide();
	var dropRecord = i2b2.WISEannotator.model.currRecord;
        i2b2.WISEannotator.model.currKeyVal = dropRecord.sdxInfo.sdxKeyValue;
        var name = dropRecord.sdxInfo.sdxDisplayName;
        i2b2.WISEannotator.model.currName = name;
        var t = "<u><b>Workplace Object: </b><i>" + name + "</i></u><p>";
        $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-text")[0].innerHTML = t;
        $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.object-title")[0].innerHTML = "&nbsp;&nbsp;" + t;
        var type = dropRecord.sdxInfo.sdxType;
        i2b2.WISEannotator.model.currType = type;

        // NOTE: eventhough any folder ("WRK") should have annotation readily attached, however, those annotation may be stale 
        //       (if they've been updated thru this annotator, or some other user updated them thru another browser session) though 
        //       -- so, they must be fetched from the DB again!
        i2b2.WISEannotator.searchRoots();

    } else if (i2b2.WISEannotator.model.skipPad) {
        //alert(".getAnnotation():\n\nname="+i2b2.WISEannotator.model.currName+",\nannotation="+i2b2.WISEannotator.model.currAnn);
        i2b2.WISEannotator.showPad(); // user must have gone directly to "Review Result" page before coming here
	i2b2.WISEannotator.model.skipPad = false;
    }

    // optimization - only requery when the input data is changed
    i2b2.WISEannotator.model.dirtyResultsData = false;

    //i2b2.h.LoadingMask.hide(); // turn off the "LOADING" mask (i2b2 Query Tool "busy, please wait" display)
    //alert("exiting .getAnnotation()");
};


// -------------------------------------------------------------------------------------------------------------------
// This method searches the root nodes to find the trunks
// -------------------------------------------------------------------------------------------------------------------
i2b2.WISEannotator.searchRoots = function() {      
    //alert("entered .searchRoots()");
    var scopedCallback = new i2b2_scopedCallback();
    scopedCallback.scope = i2b2.WORK;

    scopedCallback.callback = function(results){
        //alert("entered .searchRoots.callback()");
        var trunks = [];
        var name;
        var s;
        //var t = "";
        var notRoot = true;
	i2b2.WORK.view.main.queryResponse = results.msgResponse;
	i2b2.WORK.view.main.queryRequest = results.msgRequest;
        var nlst = i2b2.h.XPath(results.refXML, "//folder[name and share_id and index and visual_attributes]");
        for (var i = 0; i < nlst.length; i++) {
            s = nlst[i];
            trunks[trunks.length] = s;
            name = i2b2.h.getXNodeVal(s, "name");
            if ("WRK" == i2b2.WISEannotator.model.currType)
            {
                if (name == i2b2.WISEannotator.model.currName) {
                    //alert("match:\n\nname='" + name + "'\ntarget='" + i2b2.WISEannotator.model.currName + "'\n\nBUT all roots are OFF LIMIT!");
      		    alert("Please note that the top most Workplace Objects, such as '" + name + "', cannot be annotated!\n\nPlease select another Workplace Object instead.");
		    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-unsupported")[0].show();
		    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-msgs")[0].hide();
		    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-resultNext")[0].hide();
                    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.target-unsupported")[0].show();
		    notRoot = false;
                    i2b2.WISEannotator.model.targetRoot = true;
		    i2b2.h.LoadingMask.hide(); // turn off the "LOADING" mask (i2b2 Query Tool "busy, please wait" display)
                    break;
                } else {
                    //t = "no match:\n\nname='" + name + "'\ntarget='" + i2b2.WISEannotator.model.currName + "'";
		    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-unsupported")[0].hide();
                    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.target-unsupported")[0].hide();
                }
            } else {
                //t = "name=" + name + "\n\nskip this root item since target item type is '" + i2b2.WISEannotator.model.currType + "', not 'WRK'";
            }
            i2b2.WISEannotator.model.wi[i2b2.WISEannotator.model.wi.length] = s;
            //alert(t + "\n\n item-count=" + i2b2.WISEannotator.model.wi.length + "\n trunks.length=" + trunks.length);
        }
        if (notRoot) {
            i2b2.WISEannotator.searchBranches(trunks);
        }
        //alert("exiting .searchRoots.callback()");
    };

    i2b2.WORK.ajax.getFoldersByUserId("WORK:Workplace", {}, scopedCallback); // ajax communicator call
    //alert("exiting .searchRoots()");
};


// -------------------------------------------------------------------------------------------------------------------
// This method searches the tree branches for more sub-branches (it could be called recursively to exhaust branches)
// -------------------------------------------------------------------------------------------------------------------
i2b2.WISEannotator.searchBranches = function(branches) {
    //alert("entered .searchBranches():\n\nbranches.length=" + branches.length);
    var i = 0;
    var scopedCallback = new i2b2_scopedCallback();
    scopedCallback.scope = i2b2.WORK;

    scopedCallback.callback = function(results){
        //alert("entered .searchBranches.callback()");
        if ("" != i2b2.WISEannotator.model.targetName) return; // in case earlier recursive call for another twig produced a match
        var s;
        //var t = "";
        var name;
	var type;
        var twigs = [];
        i2b2.WORK.view.main.queryResponse = results.msgResponse;
	i2b2.WORK.view.main.queryRequest = results.msgRequest;
        var nlst = i2b2.h.XPath(results.refXML, "//folder[name and index and visual_attributes]");
        for (var j = 0; j < nlst.length; j ++) {
            s = nlst[j];
            name = i2b2.h.getXNodeVal(s, "name");
            if (name == i2b2.WISEannotator.model.currName) {
                i2b2.WISEannotator.model.target = s;
    		i2b2.WISEannotator.model.targetName = name;
                //alert("found it:\nname='" + name + "'\ntarget='" + i2b2.WISEannotator.model.currName + "'\ni2b2.WISEannotator.model.targetName='" + i2b2.WISEannotator.model.targetName + "'");
                break;
            } else {
		type = String(i2b2.h.getXNodeVal(s, "visual_attributes")).strip();
                //t = "no match:\n\nname='" + name + "' (type='" + type + "')\ntarget='" + i2b2.WISEannotator.model.currName + "'";
                i2b2.WISEannotator.model.wi[i2b2.WISEannotator.model.wi.length] = s;
                if ("FA" == type) {
                    twigs[twigs.length] = s;
                }
                //alert(t + "\n\n item-count="+i2b2.WISEannotator.model.wi.length + "\n twigs.length=" + twigs.length);
            }
        }
        if ("" == i2b2.WISEannotator.model.targetName) {
            if (0 < twigs.length) {
                i2b2.WISEannotator.searchBranches(twigs);
            } else {
                //alert("No more twigs to search in current tree!");
            }
        } else {
	    // somehow IE cannot handle saving an object (other browser like Chrome, Firefox, Safari, etc. are OK)
	    // it can, however, pass an object as an argument in a function call (like the other browsers)
            i2b2.WISEannotator.getTooltip(i2b2.WISEannotator.model.target);
        }
        //alert("exiting .searchBranches.callback()");
    };

    var varInput = {};
    var index;
    while (i < branches.length && "" == i2b2.WISEannotator.model.targetName) {
        index = i2b2.h.getXNodeVal(branches[i], "index");       
        varInput = {parent_key_value: index, result_wait_time: 180};
        //alert("calling i2b2.WORK.ajax.getChildren() for '" + i2b2.h.getXNodeVal(branches[i], "name") + "'");
        i2b2.WORK.ajax.getChildren("WORK:Workplace", varInput, scopedCallback); // ajax communicator call
        i ++;
    }
    //alert("exiting .searchBranches()");
};


// -------------------------------------------------------------------------------------------------------------------
// This method finalizes getting the annotation (tooltip) - parameter s is the target item to be annotated
// -------------------------------------------------------------------------------------------------------------------
i2b2.WISEannotator.getTooltip = function(s) {
    //alert("entered .getTooltip()");
    i2b2.WISEannotator.model.currKeyVal = i2b2.WISEannotator.trim(i2b2.h.getXNodeVal(s, "index"));
    i2b2.WISEannotator.model.currAnn = i2b2.WISEannotator.trim(i2b2.h.getXNodeVal(s, "tooltip"));
    //alert("exiting .getTooltip():\n\nname="+i2b2.WISEannotator.model.currName+",\nannotation="+i2b2.WISEannotator.model.currAnn);
    if (i2b2.WISEannotator.model.skipPad) {
        i2b2.WISEannotator.showAnnotation();
	i2b2.WISEannotator.model.skipPad = false;
    } else {
        i2b2.WISEannotator.showPad();
    }
};


// -------------------------------------------------------------------------------------------------------------------
// This method returns a non-null string with both leading & trailing blanks trimmed off
// -------------------------------------------------------------------------------------------------------------------
i2b2.WISEannotator.trim = function(str) {
    if (!str) { 
        return ""; 
    } else {
	return str.replace(/^\s+/,"").replace(/\s+$/,""); // trim off any leading & trailing spaces
    }
};


// -------------------------------------------------------------------------------------------------------------------
// This method renders the existing annotation (by separating paragraphs and keywords) in the "pad"
// -------------------------------------------------------------------------------------------------------------------
i2b2.WISEannotator.showPad = function() {
    //alert("entered .showPad():\n\nname="+i2b2.WISEannotator.model.currName+",\nannotation="+i2b2.WISEannotator.model.currAnn);
    //i2b2.h.LoadingMask.show(); // turn on the "LOADING" mask (i2b2 Query Tool "busy, please wait" display)
    var r = i2b2.WISEannotator.model.currAnn.split("%A%"); // separate out the 'author' portion & the rest
    r[1] = i2b2.WISEannotator.trim(r[1]);
    var s = r[0].split("%K%"); // separate out the 'keyword' portion from the leading content
    s[1] = i2b2.WISEannotator.trim(s[1]);
    var pars = s[0].split("%P%");

    var domContainer = $$("DIV#WISEannotator-mainDiv DIV.taglist")[0];
    var xTemplate = $('WISEannotator-tagrowTEMPLATE');
    // clear existing input grid
    while (domContainer.firstChild) {
        domContainer.removeChild(domContainer.firstChild);
    }
    var rec;
    var pt;
    var para = "<b>paragraph ";
    var len1 = " (length: ";
    var len2a = " characters)</b>";
    var len2b = " characters,</b> including 3 for special demarcation tag)";
    i2b2.WISEannotator.model.total = 0;
    for (i = 0; i < pars.length; i ++) {
        j = i + 1;
	// clone the record DIV and add it to the display list
	rec = xTemplate.cloneNode(true);
	rec.id = j;
        pt = pars[i].length;
        i2b2.WISEannotator.model.annLens[i] = pt;
        if (0 < pt) {       
            if (0 < i) {
                pt += 3;  // for the '%P%' tag
                Element.select(rec, '.fieldname')[0].innerHTML = para + j + len1 + pt + len2b;
            } else {
                Element.select(rec, '.fieldname')[0].innerHTML = para + j + len1 + pt + len2a;
            }
            i2b2.WISEannotator.model.total += pt;
        } else {
            Element.select(rec, '.fieldname')[0].innerHTML = para + j + len1 + pt + len2a;
            Element.select(rec, 'TEXTAREA')[0].style.background = "#FFFFFF";
        }
	Element.select(rec, 'TEXTAREA')[0].value = pars[i];
	// attach the record into the DOM tree for display
	domContainer.appendChild(rec);
	Element.show(rec);
    }
    // clone the record DIV for first spare paragraph and add it to the display list
    rec = xTemplate.cloneNode(true);
    rec.id = ++ j;
    i2b2.WISEannotator.model.annLens[i ++] = 0;
    Element.select(rec, '.fieldname')[0].innerHTML = para + j + len1 + "0 character,</b> enter new paragraph here, as needed)";
    Element.select(rec, 'TEXTAREA')[0].value = "";
    Element.select(rec, 'TEXTAREA')[0].style.background = "#FFFFFF";
    domContainer.appendChild(rec);
    Element.show(rec);
    // clone the record DIV for second spare paragraph and add it to the display list
    rec = xTemplate.cloneNode(true);
    rec.id = ++ j;
    i2b2.WISEannotator.model.annLens[i ++] = 0;
    Element.select(rec, '.fieldname')[0].innerHTML = para + j + len1 + "0 character,</b> enter new paragraph here, as needed)";
    Element.select(rec, 'TEXTAREA')[0].value = "";
    Element.select(rec, 'TEXTAREA')[0].style.background = "#FFFFFF";
    domContainer.appendChild(rec);
    Element.show(rec);
    // clone the record DIV and add it to the display list
    rec = xTemplate.cloneNode(true);
    rec.id = ++ j;
    pt = s[1].length;
    i2b2.WISEannotator.model.annLens[i ++] = pt;
    if (0 < pt) {       
        pt += 3;  // for the '%K%' tag
        i2b2.WISEannotator.model.total += pt;
        Element.select(rec, '.fieldname')[0].innerHTML = "<b>keywords (</b>'comma'-separated; <b>length: " + pt + len2b;
    } else {
        Element.select(rec, '.fieldname')[0].innerHTML = "<b>keywords (</b>'comma'-separated; <b>length: " + pt + len2a;
        Element.select(rec, 'TEXTAREA')[0].style.background = "#FFFFFF";
    }
    Element.select(rec, 'TEXTAREA')[0].value = s[1];
    domContainer.appendChild(rec);
    Element.show(rec);
    // clone the record DIV and add it to the display list
    rec = xTemplate.cloneNode(true);
    rec.id = ++ j;
    pt = r[1].length;
    i2b2.WISEannotator.model.annLens[i ++] = pt;
    if (0 < pt) {       
        pt += 3;  // for the '%A%' tag
        i2b2.WISEannotator.model.total += pt;
        Element.select(rec, '.fieldname')[0].innerHTML = "<b>author (length: " + pt + len2b;
    } else {
        Element.select(rec, '.fieldname')[0].innerHTML = "<b>author (length: " + pt + len2a;
        Element.select(rec, 'TEXTAREA')[0].style.background = "#FFFFFF";
    }
    Element.select(rec, 'TEXTAREA')[0].value = r[1];
    // remove the break line after the last row
    rec.select('.bline')[0].style.border = "none";
    domContainer.appendChild(rec);
    Element.show(rec);
    // show the whole thing	
    domContainer.show();

    var s = "&nbsp;&nbsp;&nbsp;<b>Current annotation length: " + i2b2.WISEannotator.model.total + " characters </b>(max. length allowed: 255 characters).";
    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-totalLengthTop")[0].innerHTML = s;
    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-totalLengthBot")[0].innerHTML = "&nbsp;&nbsp;&nbsp;" + s + "<br/><br/>";
    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-resultNext")[0].show();

    if (i2b2.WISEannotator.model.resultNone) {
        i2b2.WISEannotator.showAnnotation();
    }
    //i2b2.h.LoadingMask.hide(); // turn on the "LOADING" mask (i2b2 Query Tool "busy, please wait" display)
    //alert("exit .showPad()");    
};


// -------------------------------------------------------------------------------------------------------------------
// This method updates the length of the annotation (each segment as well as the total)
// -------------------------------------------------------------------------------------------------------------------
i2b2.WISEannotator.updateLength = function() {
    var desc = ["length: ", " character", "s", ")</b>", ",</b> including 3 characters for special demarcation tag)"];
    var tags = ["%P%", "%K%", "%A%", "keywords", "author"];
    var p = [];
    var tav;
    var fn;
    var al;
    var ann = "";
    var ttl = 0;
    var trs = $$("DIV#WISEannotator-mainDiv DIV.taglist DIV.tagrow");
    var reduceOnly;
    if (254 < i2b2.WISEannotator.model.total) {
        reduceOnly = true;
    } else {
        reduceOnly = false;
    }

    for (var i = 0; i < trs.length; i ++) {
        tav = i2b2.WISEannotator.trim(trs[i].select('textarea')[0].value); // strip off any meaningless leading & trailing spaces
        al = tav.length;
        if (reduceOnly && (al > i2b2.WISEannotator.model.annLens[i])) {
            al = i2b2.WISEannotator.model.annLens[i];
            if (0 < al) {	
	        tav = tav.substr(0, al);
	    } else {
		tav = "";
	    }
            trs[i].select('textarea')[0].value = tav;
            alert("Cannot add any more text to the annotation, as it is already at the length limit of 255 characters!\n\nPlease trim only.");
            trs[i].select('textarea')[0].style.background = "#FF0033";
            trs[i].select('textarea')[0].style.color = "#FFFF00";
        } else if (al != i2b2.WISEannotator.model.annLens[i]) {
            i2b2.WISEannotator.model.annLens[i] = al;
            trs[i].select('textarea')[0].style.background = "#FFDFF8";
            trs[i].select('textarea')[0].style.color = "#000000";
        }

	p = Element.select(trs[i], '.fieldname')[0].innerHTML.split(desc[0]);
        if (0 == al) {
            fn = p[0] + desc[0] + "0 character)";
        } else {
            //alert("p[0]='"+p[0]+"'\ntags[3]='"+tags[3]+"', tags[1]='"+tags[1]+"'\ntags[4]='"+tags[4]+"', tags[2]='"+tags[2]+"'\ntags[0]='"+tags[0]+"'");
            if (0 < i) {
                al += 3;  // for the '%P%', '%K%', or '%A%' tag
                if (3 == p[0].indexOf(tags[3])) {
  	            ann += tags[1];
		} else if (3 == p[0].indexOf(tags[4])) {
                    ann += tags[2];
		} else {
		    ann += tags[0];
		} 
                fn = p[0] + desc[0] + al + desc[1] + desc[2] + desc[4];
            } else {
                if (1 == al) {               
                    fn = p[0] + desc[0] + al + desc[1] + desc[3];
                } else {
                    fn = p[0] + desc[0] + al + desc[1] + desc[2] + desc[3];
                }
            }
            ann += tav;            
            ttl += al;
        }
        Element.select(trs[i], '.fieldname')[0].innerHTML = fn;
    }
    i2b2.WISEannotator.model.total = ttl;
    i2b2.WISEannotator.model.ann = ann;
    //alert("i2b2.WISEannotator.model.ann="+i2b2.WISEannotator.model.ann);

    // refresh the whole thing	
    $$("DIV#WISEannotator-mainDiv DIV.taglist")[0].show();

    var s = "&nbsp;&nbsp;&nbsp;<b>Current annotation length: " + ttl + " characters </b>(max. length allowed: 255 characters).";
    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-totalLengthTop")[0].innerHTML = s;
    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.annotate-totalLengthBot")[0].innerHTML = "&nbsp;&nbsp;&nbsp;" + s + "<br/><br/>";
    i2b2.WISEannotator.model.resultPending = true;};


// -------------------------------------------------------------------------------------------------------------------
// This method submits the updated annotation
// -------------------------------------------------------------------------------------------------------------------
i2b2.WISEannotator.updateShowResult = function() {
    //alert("entered .updateShowResult()");
    $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-directions")[0].hide();
    i2b2.h.LoadingMask.show(); // turn on the "LOADING" mask (i2b2 Query Tool "busy, please wait" display)

    var newAnn = i2b2.WISEannotator.model.ann;
    if (255 < newAnn.length) {
        alert("The annotation has exceeded the length limit -- please trim it down!");
	return;
    } 

    //alert("newAnn="+newAnn+"\noldAnn="+i2b2.WISEannotator.model.currAnn+"\ni2b2.WISEannotator.model.targetName="+i2b2.WISEannotator.model.targetName);
    var scopedCallback = new i2b2_scopedCallback();
    scopedCallback.scope = i2b2.WORK;
    scopedCallback.callback = function(results) {
    //alert("entered .updateShowResult.callback()");
	i2b2.WORK.view.main.queryResponse = results.msgResponse;
	i2b2.WORK.view.main.queryRequest = results.msgRequest;
	if (results.error) {
            alert("An error occurred while trying to annotate the selected object!");
	} else {
            //alert("annotation updated!");
	}

	// to trigger refresh of annotation from DB for "Review Result" page
        // unfortunately can't just use annotation again from the cached object, as the annotation would be stale (not the updated one)
	i2b2.WISEannotator.model.skipPad = true;
	i2b2.WISEannotator.model.targetName = "";
        i2b2.WISEannotator.searchRoots(); // this will refresh everything from DB, including the annotation pad, which the user may revisit         
	//i2b2.h.LoadingMask.hide(); // turn off the "LOADING" mask
        //alert("exiting .updateShowResult.callback()");
    };

    // somehow IE cannot handle saving an object (other browser like Chrome, Firefox, Safari, etc. are OK) -- so can't use the next block on IE; any way, the scenario really won't happen 
    //if ("" == i2b2.WISEannotator.model.currAnn && "" != i2b2.WISEannotator.model.target) {
    //   var s = i2b2.WISEannotator.model.target;
    //   i2b2.WISEannotator.model.currKeyVal = i2b2.WISEannotator.trim(i2b2.h.getXNodeVal(s, "index"));
    //   i2b2.WISEannotator.model.currAnn = i2b2.WISEannotator.trim(i2b2.h.getXNodeVal(s, "tooltip"));
    //}

    //alert(".updateShowResult():\n\nnewAnn="+newAnn+",\n\noldAnn="+i2b2.WISEannotator.model.currAnn);
    if (i2b2.WISEannotator.model.currAnn == newAnn) { 
        alert("There is no change (leading or trailing spaces are stripped away and won't count) in the current annotation!");
        $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-msgs")[0].hide();
        $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-noChange")[0].show();
        i2b2.WISEannotator.model.resultPending = false;
        i2b2.WISEannotator.showAnnotation(); 
    } else {
        var key = i2b2.WISEannotator.model.currKeyVal;
        //var n = i2b2.WISEannotator.model.currName;
        //var oldAnn = i2b2.WISEannotator.model.currAnn;
        //alert(".updateShowResult():\n\nupdating annotation for '" + n + "',\nkeyVal:'" + key + "' --\n\n original: '" + oldAnn + "',\n\n   update: '" + newAnn + "'");
        var varInput= {annotation_text: newAnn, annotation_target_id: key, result_wait_time: 180};
        i2b2.WORK.ajax.annotateChild("WORK:Workplace", varInput, scopedCallback); // ajax communicator call
        $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-noChange")[0].hide();
        $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-msgs")[0].show();
    }
    //i2b2.h.LoadingMask.hide(); // turn off the "LOADING" mask (i2b2 Query Tool "busy, please wait" display)
    //alert("exiting .updateShowResult()");
};


// -------------------------------------------------------------------------------------------------------------------
// This method displays the annotation
// -------------------------------------------------------------------------------------------------------------------
//i2b2.WISEannotator.showAnnotation = function(s) {
i2b2.WISEannotator.showAnnotation = function() {
    //i2b2.h.LoadingMask.show(); // turn on the "LOADING" mask (i2b2 Query Tool "busy, please wait" display)
    var ann;
    // somehow IE cannot handle saving an object (other browser like Chrome, Firefox, Safari, etc. are OK) -- so can't use the next block on IE; any way, the scenario really won't happen 
    //if ("" == i2b2.WISEannotator.model.currAnn && "" != i2b2.WISEannotator.model.target) {
    //    ann = i2b2.WISEannotator.trim(i2b2.h.getXNodeVal(i2b2.WISEannotator.model.target, "tooltip"));
    //} else {
    //    ann = i2b2.WISEannotator.model.currAnn;
    //}
    ann = i2b2.WISEannotator.model.currAnn;
    //alert(".showAnnotation():\n\nname="+i2b2.WISEannotator.model.currName+",\nannotation="+ann);

    var r = ann.split("%A%"); // separate out the 'author' portion & the rest
    r[1] = i2b2.WISEannotator.trim(r[1]);
    var s = r[0].split("%K%"); // separate out the 'keyword' portion from the leading content
    s[1] = i2b2.WISEannotator.trim(s[1]);
    var t = i2b2.WISEannotator.trim(s[0]).replace(/%P%/g, "<p>");
    
    // %K% & %A% may or may not be present
    t += '<p><table><tr><th>keyword(s)</th><td bgcolor="#ECF0FF"><b><i>' + s[1] + '</i></b></td></tr>';
    t += '<tr><th>author</th><td bgcolor="#ECF0FF"><i>' + r[1] + '</i></td></tr></table>';
    
    var sdxDisplay = $$("DIV#WISEannotator-mainDiv DIV#annotation-InfoSDX")[0];
    Element.select(sdxDisplay, '.sdxAnnotation')[0].innerHTML = t;

    if (i2b2.WISEannotator.model.resultNone || !i2b2.WISEannotator.model.resultPending) {
	i2b2.WISEannotator.model.resultNone = false;
        $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-noChange")[0].show();
    } else {
        $$("DIV#WISEannotator-mainDiv DIV#WISEannotator-TABS DIV.results-noChange")[0].hide();
	i2b2.WISEannotator.showPad(); // updated the "Annotate" page as well
    }
    i2b2.h.LoadingMask.hide(); // turn on the "LOADING" mask (i2b2 Query Tool "busy, please wait" display)
    //alert("exiting .showAnnotation()");    
};



// -------------------------------------------------------------------------------------------------------------------
// This method wraps a long group of contiguous characters into multiple lines of a given width
// -------------------------------------------------------------------------------------------------------------------
i2b2.WISEannotator.wrapParagraph = function(p, width) {
    var t;
    var p1;
    var p2;
    if (width < p.length) {
        p1 = p.substr(0, width);
        //alert("p1="+p1);
        p2 = Math.min(width, Math.max(p1.lastIndexOf(" "), p1.lastIndexOf(","), p1.lastIndexOf("."), p1.lastIndexOf(";"), p1.lastIndexOf("?"), p1.lastIndexOf("!")));
        //alert(width+", "+p1.lastIndexOf(" ")+", "+p1.lastIndexOf(",")+", "+p1.lastIndexOf(".")+", "+p1.lastIndexOf(";")+", "+p1.lastIndexOf("?")+", "+p1.lastIndexOf("!"));
        if (p2 < width && p2 > 0) {
            p1 = p.substr(0, p2);
        } else {
            p2 = width;
        }
        //alert("p2="+p2+", p1="+p1+", p.substr(p2, p.length)="+p.substr(p2, p.length));
        t = p1 + "<br/>" + i2b2.WISEannotator.wrapParagraph(p.substr(p2, p.length));
    } else {
        t = p;
    }
    return t;
};

